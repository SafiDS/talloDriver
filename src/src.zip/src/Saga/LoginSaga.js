import { takeLatest, call, put, delay } from 'redux-saga/effects'
import { saveToStorage, getItemFromStorage } from '../utils/AccessStorage'
import API from '../Api'
import { saveUserInfo } from '../utils/User'
import { Alert, Platform,ToastAndroid} from "react-native";
import { navigate, navigateScreen } from '../Tools/NavigationServices'
import AsyncStorage from '@react-native-community/async-storage';
import { useDispatch,useSelector } from 'react-redux'
import StaticText from '../utils/StaticText'


const api = API.create()


export function* SignInSaga(action) {
  //alert("hi")
  
  let params = {}


  
   api.setHeader("content-type", "application/json",)
    params["phone"] = action.payload;
    

      if(params["phone"].length != 10){
       
       alert("Please Enter Valid Mobile Number")
       return
      }
  
  const response = yield call(api.rider_login_otp_request, params)

        console.log("response is " , response)
        console.log(params)
  if (response.status == 200) {
    if (response.data["statusCode"] == "SUCCESS") {
      response.data["phone"] = action.payload;
      saveToStorage("PhoneNumber", response.data.phone)
      yield put({
        type: 'LOGIN_DETAILS',
        payload: response.data
      })
    navigate('Otp')
//navigate('UploadImage')
    }
    else {
      alert(response.data.statusMessage)
    }
  }
}





export function* OTPSaga(action) {
  let params = {}
  const { phone, navigation, otp } = action.payload
  console.log("Token",StaticText.Token)
  params["phone"] = phone;
  params["otp"] = otp;
  params["devicetoken"] = StaticText.Token;
  console.log(params)
  
  if(typeof (params["otp"]) == 'undefined' || params["otp"] == null || params["otp"] == ''){
       
    Alert.alert("Please Enter Otp")
    return
   }
  const response = yield call(api.rider_login_otp_verify, params)
 
console.log("otp++",response.data)
  if (response.data["user_info"] == ""){
    if (response.data["statusCode"] == "SUCCESS") {
      StaticText.RiderId = response.data.rider_info.rider_id
     // saveToStorage("RiderId", response.data.rider_info.rider_id)
      saveToStorage("PhoneNumber", phone)
      navigateScreen(navigation, 'SignUpScreen')

    }

  }


  if (response.data["user_info"] != ""){
    if (response.data["statusCode"] == "SUCCESS") {
       saveToStorage("RiderId", response.data.rider_id)
       StaticText.RiderId = response.data.rider_id
      saveToStorage("PhoneNumber", phone)
      saveToStorage("User_info", JSON.stringify(response.data))
      navigateScreen(navigation, 'SignUpScreen')

      yield put({
        type: 'USER_INFORMATION',
        payload: response.data
      })
    }
    }else{

       Alert.alert(response.data.statusMessage)
    }

  


  
}



export function* Registration(action) {
  let params = {}
  const { Name, Date, Email, City,Vehicle, gender, navigation, phone } = action.payload
  console.log("Token",StaticText.Token)
//alert("Hi")
  //navigateScreen(navigation, 'Language')
  //api.setContentType(api.applicationJson)
  params["phone"] = phone;
  params["full_name"] = Name;
  params["email"] = Email;
  params["dob"] = Date;
  params["city"] = City;
  params["vehicle_type"] = Vehicle;
  params["gender"] = gender;
  params["devicetoken"] = StaticText.Token;
  console.log(params)
  //navigateScreen(navigation, 'Language')
  if(params["full_name"] == ""){
    ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
   }else if(params["dob"] == ""){
    ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
   
   } else if(params["city"]==""){
    ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
   }else if(params["gender"]==""){
    ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
   }else{
  const response = yield call(api.rider_profile_update, params)
 console.log("RESponse ===",response.data)
  if (response.status == 200) {
    if (response.data["statusCode"] == "SUCCESS") {
     // saveToStorage("RiderId",response.data.rider_info.id)
   
      navigateScreen(navigation, 'Language')
      //navigateScreen(navigation, 'Dashboard')
      saveToStorage("User_info", JSON.stringify(response.data))
      yield put({
        type: 'USER_INFORMATION',
        payload: response.data
      })
    }
    else {
      console.log(response.data.statusCode)
     
    }
 }

   }
  
}


export function* Language(action) {
  let params = {}
  const { Name, Date, Email, City, gender, navigation, phone } = action.payload

  navigateScreen(navigation, 'License')
  
}



export function* License(action) {
  let params = {}
  const { LisenceNo,FrontImage,BackImage, navigation, } = action.payload
  console.log("params",params)
  // api.setContentType(api.applicationJson)
  params["LisenceNo"] = LisenceNo;
  params["FrontImage"] = FrontImage;
  params["BackImage"] = BackImage;
  
    yield put({
      type: 'LICENSEDATA',
      payload: params
    })
    
navigateScreen(navigation, 'RCDocument')
  
  
}

export function* Rcdocoment(action) {
  let params = {}
  const {  RCNo, RCFrontImage, RCBackImage, navigation } = action.payload

  params["RCNo"] = RCNo;
  params["RCFrontImage"] = RCFrontImage;
  params["RCBackImage"] = RCBackImage;
 
  yield put({
    type: 'RCDATA',
    payload: params
  })
  navigateScreen(navigation, 'Insurance')

}

export function* Insurance(action) {
  let params = {}
  const {InsuranceNo,InBackImage, navigation, InFrontImage, } = action.payload
  params["InFrontImage"] = InFrontImage;
  params["InBackImage"] = InBackImage;
  params["InsuranceNo"] = InsuranceNo;
 
  yield put({
    type: 'INSURANCEDATA',
    payload: params
  })
  navigateScreen(navigation, 'Pancard')
 
  
}


export function* Pancard(action) {
  let params = {}
  const {PCNo,PCFrontImage, navigation } = action.payload
params["PCNo"] = PCNo;
  params["PCFrontImage"] = PCFrontImage;
  
  yield put({
    type: 'PCDATA',
    payload: params
  })
  navigateScreen(navigation, 'Aadharcard')
 

}


export function* Adarcard(action) {
  let params = {}
  const { AadharNo, ACFrontImage, ACBackImage, navigation } = action.payload
  params["AadharNo"] = AadharNo;
  params["ACFrontImage"] = ACFrontImage;
  params["ACBackImage"] = ACBackImage;
 
  yield put({
    type: 'ACDATA',
    payload: params
  })
  navigateScreen(navigation, 'Bankdetails')

}

export function* BankDetails(action) {
  let params = {}
  const { AccountName,AccountNo,BankName,IFSC, navigation} = action.payload
 params["AccountName"] = AccountName;
  params["AccountNo"] = AccountNo;
  params["BankName"] = BankName;
  params["IFSC"] = IFSC;
 
  yield put({
    type: 'BANKDATA',
    payload: params
  })
  navigateScreen(navigation, 'UploadImage')

}

export function* UploadImage(action) {
  let params = {}
  const { rider_id,full_name,email, navigation,dob,city,gender,devicetoken,driving_license_number,driving_license_front_image,driving_license_back_image, rc_number,rc_front_image,rc_back_image,insurance_number,insurance_front_image,insurance_back_image,
    pancard_number,pancard_image,aadharcard_number,aadharcard_front_image,aadharcard_back_image,bank_account_holder_name,bank_account_number,bank_name,bank_ifsc,profile_image} = action.payload
//   let id, full_name,email,gender;

 
  // api.setContentType(api.applicationJson)
   params["rider_id"] = rider_id;
  params["full_name"] = full_name;
  params["email"] = email;
  params["dob"] = dob;
  params["city"] = city;
  params["gender"] = gender;
  params["devicetoken"] = StaticText.Token;
  params["driving_license_number"] = driving_license_number;
  params["driving_license_front_image"] = driving_license_front_image;
  params["driving_license_back_image"] = driving_license_back_image;
  params["rc_number"] = rc_number;
  params["rc_front_image"] = rc_front_image;
  params["rc_back_image"] = rc_back_image;
  params["insurance_number"] = insurance_number;
  params["insurance_front_image"] = insurance_front_image;
  params["insurance_back_image"] = insurance_back_image;
  params["pancard_number"] = pancard_number;
  params["pancard_image"] = pancard_image;
  params["aadharcard_number"] = aadharcard_number;
  params["aadharcard_front_image"] = aadharcard_front_image;
  params["aadharcard_back_image"] = aadharcard_back_image;
  params["bank_account_holder_name"] = bank_account_holder_name;
  params["bank_account_number"] = bank_account_number;
  params["bank_name"] = bank_name;
  params["bank_ifsc"] = bank_ifsc;
  params["profile_image"] = profile_image;
 
 // console.log("PRAMS+++++++++++++++++++",params)
 //navigateScreen(navigation, 'ChangeImage')
   const response = yield call(api.rider_full_profile_update, params)
    console.log("REsponse=========",response.data.rider_info)
  //navigateScreen(navigation, 'ChangeImage')
  if (response.status == 200) {
    if (response.data["statusCode"] == "SUCCESS") {
      saveToStorage("RiderId",response.data.rider_info.id)
     yield put({
        type: 'USER_INFORMATION',
        payload: response.data
      })
      navigateScreen(navigation, 'ChangeImage')
    }
    else {
      alert(response.data.statusMessage)
    }
  }
}

export function* RiderChangeImage(action) {
  let params = {}
  const { rider_id, navigation, profile_image } = action.payload
  // api.setContentType(api.applicationJson)
  params["rider_id"] = rider_id;
  params["profile_image"] = profile_image;
  console.log("params+++++++++++",params)

 
 
   const response = yield call(api.rider_profile_image_update, params)
 
  if (response.status == 200) {
    if (response.data["statusCode"] == "SUCCESS") {
       yield put({
        type: 'USER_INFORMATION',
        payload: response.data
      })
      navigateScreen(navigation, 'RiderDetails')
    }
    else {
      alert(response.data.statusMessage)
    }
  }
}

export function* RiderDetails(action) {
  let params = {}
  const { Name, Date, Email, City, gender, navigation, phone } = action.payload

  navigateScreen(navigation, 'Dashboard')
  // api.setContentType(api.applicationJson)
  // params["phone"] = phone;
  // params["full_name"] = Name;
  // params["email"] = Email;
  // params["dob"] = Date;
  // params["city"] = City;
  // params["gender"] = gender;
  // params["devicetoken"] = "34567890";
  // const response = yield call(api.user_profile_update, params)
 
  // if (response.status == 200) {
  //   if (response.data["statusCode"] == "SUCCESS") {
      
  //     navigateScreen(navigation, 'LoginScreen')
  //     saveToStorage("User_info", JSON.stringify(response.data))
  //     yield put({
  //       type: 'USER_INFORMATION',
  //       payload: response.data
  //     })
  //   }
  //   else {
  //     alert(response.data.statusMessage)
  //   }
  // }
}

export function* Dashboard(action) {
  let params = {}
  const {  navigation, phone } = action.payload

  navigateScreen(navigation, 'RiderStatusGoToHome')
}


export function* RiderStatusGotoHome(action) {
  let params = {}
  const {  navigation, phone } = action.payload

  navigateScreen(navigation, 'RiderStatusOnline')
}


export function* RiderStatusOnline(action) {
  let params = {}
  const {  navigation, phone } = action.payload

  navigateScreen(navigation, 'RiderStatusOnline1')
}

export function* RiderStatusOnline1(action) {
  let params = {}
  const {  navigation, phone } = action.payload

  navigateScreen(navigation, 'RiderGoToHome')
}





export function* cityList(action) {
  debugger
  const response = yield call(api.City_name) 
  api.setContentType(api.applicationJson)

  if (response.data.message == "success") {
    if (response.data.message == "success") {
   
      saveToStorage("User_info", JSON.stringify(response.data.data))
      yield put({
        type: 'USER_INFORMATION',
        payload: response.data.data
      })
    }
    else {
      alert(response.data.statusMessage)
    }
  }
}

export function* GetRiderDetails(action) {
const params = action.params

//console.log('++++++++++++++++++++++++HI+++++++++++',params)
const users = yield call(api.rider_info, params)
console.log("user++",users)
AsyncStorage.setItem('user_data',JSON.stringify(users))
yield put({ type: "SAVE", payload: users.data });
}

export function* RiderLocationUpdate(action) {
  let params = {}
  const {  rider_id, lat, lon, online_status } = action.payload

  
  params["rider_id"] = rider_id;
  params["lat"] = lat;
  params["lon"] = lon;
  params["online_status"] = online_status;
 console.log(params)
  // params["gender"] = gender;
  // params["devicetoken"] = "34567890";
  // var request = {
  //   "rider_id":"1",
  //   "lat":"17.4391852",
  //   "lon":"78.4271108",
  //   "online_status":"1"
  //   }
   const response = yield call(api.rider_location_update, params)
   console.log("Location Update",response)
}

export function* BookingInfo(action) {
  let params = {}
  const {booking_id} = action.payload

  
  params["booking_id"] = booking_id;
 
 console.log(params)
 
   const response = yield call(api.booking_info, params)
   saveToStorage("source",response.data.booking_data.source)
   saveToStorage("destination",response.data.booking_data.destination)
   yield put({ type: "BOOKINGINFO", payload: response.data.booking_data });
   console.log("Booking Info",response)
}

export function* RiderBookingAccept(action) {
  let params = {}
  const {booking_id,rider_id,navigation} = action.payload

  
  params["booking_id"] = booking_id;
  params["rider_id"] = rider_id;
 console.log(params)
  
 const response = yield call(api.booking_accept,params) 
  
 console.log("Booking accept",response.data)

 if (response.data["statusCode"] == "SUCCESS") {
  navigateScreen(navigation, 'RiderMultipleDestination')
   
    }
    else {
      alert(response.data.statusMessage)
    }
  }



  export function* RiderReachLocation(action) {
    let params = {}
    const {booking_id,rider_id,navigation} = action.payload
  
    
    params["booking_id"] = booking_id;
    params["rider_id"] = rider_id;
   console.log(params)
  const response = yield call(api.booking_source_location_reach,params) 
   console.log("Reach Locationt",response.data)
  
   if (response.data["statusCode"] == "SUCCESS") {
    navigateScreen(navigation, 'RiderHomeOtp')
     
      }
      else {
        alert(response.data.statusMessage)
      }
    }

  export function* BookingOtpVerify(action) {
      let params = {}
      const {booking_id,rider_id,booking_otp,navigation} = action.payload
    
      
      params["booking_id"] = booking_id;
      params["rider_id"] = rider_id;
      params["booking_otp"] = booking_otp;
     console.log(params)
    const response = yield call(api.booking_otp_verify,params) 
     console.log("booking otp",response.data)
    
     if (response.data["statusCode"] == "SUCCESS") {
      navigateScreen(navigation, 'RiderOngoingRide')
       
        }
        else {
          alert(response.data.statusMessage)
        }
      }



      export function* BookingComplete(action) {
        let params = {}
        const {booking_id,rider_id,destination,destination_lat,destination_lon,navigation} = action.payload
      
        
        params["booking_id"] = booking_id;
        params["rider_id"] = rider_id;
        params["destination"] = destination;
        params["destination_lat"] = destination_lat;
        params["destination_lon"] = destination_lon;
       console.log(params)
      const response = yield call(api.booking_complete,params) 
       console.log("booking otp",response)
      
      //  if (response.data["statusCode"] == "SUCCESS") {
      //   //navigateScreen(navigation, 'SuccessScreen')
      //    console.log("Succes  booking complete")
      //     }
      //     else {
      //       alert(response.data.statusMessage)
      //     }
        }


