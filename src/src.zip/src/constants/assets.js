export const male = require("../assets/icons/male.png");
export const activeM = require("../assets/icons/activeM.png");
export const female = require("../assets/icons/female.png");
export const activeF = require("../assets/icons/activeF.png");

// export const checkbox = require("");
export const activeC = require("../assets/icons/success.png");

export default {
    male, activeM,female, activeF,activeC
}