import React, { useState } from 'react'
import {
  View,
  Button, Text,
  TextInput, TouchableOpacity,
  StyleSheet, Image , StatusBar,ToastAndroid
} from 'react-native'
import { getStoreValue } from '../../Tools/StoreHandler'
import { useDispatch } from 'react-redux'
import { getItemFromStorage } from '../../utils/AccessStorage'
import { Images } from '../../utils'
import Appicon from "../../components/Appicon";
import { ScrollView } from 'react-native-gesture-handler'
import AntDesign from 'react-native-vector-icons/AntDesign';
import AsyncStorage from '@react-native-community/async-storage'
import { navigate, navigateScreen } from '../../Tools/NavigationServices'

export default function Bankdetails({ navigation }) {
  const dispatch = useDispatch();

  const [AccountName, setAccountName] = useState("")
  const [AccountNo, setAccountNo] = useState("")
  const [ConAccountNo, setConAccountNo] = useState("")
  const [BankName, setBankName] = useState("")
  const [IFSC, setIFSC] = useState("")
  StatusBar.setHidden(true);

  React.useEffect(() => {
    // Create an scoped async function in the hook
    async function anyNameFunction() {
      const GetDetails = await getItemFromStorage('PhoneNumber')
      if (!GetDetails) { }
      else { SetPhone(GetDetails) }

    }
    // Execute the created function directly
   // anyNameFunction();
  }, []);


  function _signUp() {
    if(AccountName == ""){
      ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
     }else if(AccountNo == ""){
      ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
     }else if(ConAccountNo == ""){
      ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
     }else if (AccountNo!=ConAccountNo) {
      ToastAndroid.showWithGravity("Account no. and confirm account no. should be same.",ToastAndroid.LONG, ToastAndroid.CENTER);
    }
       else if(BankName==""){
      ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
     } else if(IFSC==""){
      ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
     }
     else{
    var request = {
      "AccountName": AccountName,
      "AccountNo": AccountNo,
      "BankName": BankName,
      "IFSC": IFSC,
      "navigation": navigation
    }
    dispatch({ type: 'Bank_Details', payload: request })
  }
  }


  



  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>


      <ScrollView>
      {/* <View style = {{height:100 , backgroundColor:'#F87300' , borderBottomLeftRadius:0 , borderBottomRightRadius:0  }}>
      <Appicon icon={require("../../assets/icons/tallo-logo-main.png")} />
      </View> */}


   
<View style = {{ marginTop:1 , marginBottom:190 ,marginLeft:0,height:5,flexDirection: 'column',justifyContent: 'space-around'}}>
            <Image style={{ width: 392, height: 240, alignSelf: 'center' }} source={require('../../assets/Images/logoscreen.png')} />
            {/* <Image style={{ marginTop:0 , marginBottom:0, width: 102, height: 40,marginLeft:15 }} source={require('../../assets/icons/tallo-logo-main.png')} /> */}
                     
<View style = {{ marginTop:1 , marginBottom:40 ,marginLeft:0,height:5,flexDirection: 'row'}}>
  {/* <Image style={{ marginTop:0 , marginBottom:0, width: 32, height: 30,marginLeft:5 }} source={require('../../assets/Images/BackButton.png')} /> */}
  <Image style={{ marginTop:-50 , marginBottom:0,width: 112, height: 47,marginLeft:75 }} source={require('../../assets/icons/tallo-logo-main.png')} />
</View>

<TouchableOpacity  onPress={()=>navigate('Aadharcard')}>
<Image style={{ marginTop:10 , marginBottom:0, width: 42, height: 42,marginLeft:15 }} source={require('../../assets/Images/BackButton.png')} />
  </TouchableOpacity>

  </View>
  
        <View style={styles.container}>
          <View style={{ marginBottom: 10, marginLeft: 0 }}>
          </View>
          <View style={{ textAlign: 'left' }}>
            <Text style={[styles.logintext, { color: '#000000', fontFamily: 'Montserrat-Bold' }]}>Bank Details</Text>
            <View style={{ marginTop: 10 }}>
              <TextInput
                style={styles.input}
                placeholder='Account Name'
                autoCapitalize="none"
                placeholderTextColor="#808080"
                onChangeText={(mobile) => setAccountName(mobile)}
              />
              <TextInput
                style={styles.input}
                placeholder='Account Number'
                autoCapitalize="none"
                placeholderTextColor="#808080"
                onChangeText={(mobile) => setAccountNo(mobile)}
              />
              <TextInput
                style={styles.input}
                placeholder='Confirm Account Number'
                autoCapitalize="none"
                placeholderTextColor="#808080"
                onChangeText={(mobile) => setConAccountNo(mobile)}
              />
              <TextInput
                style={styles.input}
                placeholder='Bank Name'
                autoCapitalize="none"
                placeholderTextColor="#808080"
                onChangeText={(mobile) => setBankName(mobile)}
              />
               <TextInput
                style={styles.input}
                placeholder='IFSC'
                autoCapitalize="none"
                placeholderTextColor="#808080"
                onChangeText={(mobile) => setIFSC(mobile)}
              />
              </View>   
               
              <View style = {styles.imageAvater}>
                                
                                <TouchableOpacity style={styles.uploadImageBtn} onPress={() => _signUp()}>
                                    <AntDesign name="upload" size={30} color="#808080" />
                               <Text style={styles.uploadtext}>Upload Cheque</Text>
                             </TouchableOpacity>
                             
                                               
          </View>
          <TouchableOpacity style={styles.loginBtn} onPress={() => _signUp()}>
                <Text style={styles.buttontext}>Confirm</Text>
              </TouchableOpacity> 
          </View>

        </View>
     
      </ScrollView>
    </View>
  )
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    width: 370,
    height: 40,
    marginLeft: 5,
    marginRight: 5,
    marginBottom: 15,
    padding: 0,
    paddingLeft: 10,
    color: '#000',
    fontSize: 16,
    borderColor: "#d9d9d9",
    borderWidth: 1,
    elevation: 4,
    shadowOffset: { width: 10, height: 10 },
    shadowColor: "grey",
    shadowOpacity: 0.5,
    backgroundColor: "#fbfbfb",
    borderRadius: 20,
  },
  logintext: {
    padding: 3,
    marginLeft: 10,
    color: '#000000',
    fontSize: 20,
  },

  loginBtn: {
    borderRadius: 5,
    height: 35,
    marginLeft: 50,
    marginRight: 60,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    marginTop: 20,
    backgroundColor: "#F87300",
    marginBottom:30
  },
  buttontext: {
    color: '#fff',
    fontSize: 16, fontWeight: 'bold'
  },

  imageAvater:{
    paddingVertical: 30,
    padding:50,
    width: 300,
    height: 180,
    borderRadius: 7,
    marginLeft:40,
    backgroundColor:'#fff',
    borderWidth:1,
    borderStyle: 'dashed',
    margin:10
   },
   uploadImageBtn: {
    borderRadius: 5,
    height: 35,
    // marginLeft: 50,
    // marginRight: 60,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    // marginTop: 40,
    // backgroundColor: "#F87300",
    marginTop:50,
  },
  uploadtext: {
    color: '#808080',
    fontSize: 16,
    marginTop:5
  },
  
})