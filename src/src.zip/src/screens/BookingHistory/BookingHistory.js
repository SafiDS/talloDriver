import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    View,
    TextInput,
    TouchableOpacity,
    Alert,
    Image,
    KeyboardAvoidingView,
     ScrollView,
     StatusBar,
     FlatList
} from "react-native";
import { themes } from '../../utils'
import { useDispatch } from 'react-redux'
import { Button, Popup, Input } from '../../components'
// import Gender from "../../components/Gender";
import Appicon from "../../components/Appicon";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { navigate, navigateScreen } from '../../Tools/NavigationServices'

export default function BookingHistory({ navigation }) {
    const pickupdata = [
      
        {
          id: '1235 , 6th cross crossman street , LA , USA ',
          title: 'Pickup Location',
          droplocation:"Drop Location",
          dropplace:"34, Narman road,opposite to econimcs buldind,USA"
        },
        {
            id: '232 , 6th cross crossman street , LA , USA ',
            title: 'Pickup Location',
            droplocation:"Drop Location",
            dropplace:"232, Narman road,opposite to econimcs buldind,USA"
          },
          {
            id: '3232 , 6th cross crossman street , LA , USA ',
            title: 'Pickup Location',
            droplocation:"Drop Location",
            dropplace:"34, Narman road,opposite to econimcs buldind,USA"
          },
    
          {
            id: '232 , 6th cross crossman street , LA , USA ',
            title: 'Pickup Location',
            droplocation:"Drop Location",
            dropplace:"34, Narman road,opposite to econimcs buldind,USA"
          },
          {
            id: '2323 , 6th cross crossman street , LA , USA ',
            title: 'Pickup Location',
            droplocation:"Drop Location",
            dropplace:"34, Narman road,opposite to econimcs buldind,USA"
          },
    
      ];



      const Item = ({ title  , id , droplocation , dropplace}) => (
   
        <View style={styles.item}>


<View style={{ flexDirection: 'row', marginStart: 1 }}>
 
<View style={{ flexDirection: 'column', marginStart: 1 ,marginTop: 15,marginRight: 10}}>
<Image style={{ width: 15, height: 15,marginTop: 0, marginStart: 0 }} source={require('../../assets/Images/Path2.png')} />
<Image style={{ width: 5, height: 35,marginTop: 0, marginStart: 6 }} source={require('../../assets/Images/Path3.png')} />
<Image style={{ width: 15, height: 15,marginTop: 0, marginStart: 0 }} source={require('../../assets/Images/Path1.png')} />
</View>

<View>
<Text style={styles.title}>{title}</Text>
          <Text style={styles.title1}>{id}</Text>
          <Text style={styles.title}>{droplocation}</Text>
          <Text style={styles.title1}>{dropplace}</Text>
</View>
</View>  


<View style = {{marginTop:10 , flexDirection:'row'}}>
<Image style={{ width: 35, height: 35,marginTop: 0, marginStart: 0 }} source={require('../../assets/Images/photo.png')} />

         <View>
           
          <View style = {{marginTop:5 , flexDirection:'row',justifyContent:'space-between',marginLeft: 20}}>

              <Text style ={{color:'black' , fontWeight:'bold', fontSize:16, marginStart: 10}}>Mike Daniel</Text>
              <Text style ={{color:'gray' , fontWeight:'bold', fontSize:16, marginStart: 10}}>Avg time</Text>
              <Text style ={{color:'gray' , fontWeight:'bold', fontSize:16, marginStart: 10}}>Rs.470.00</Text>
            
              </View>
              <View style ={{flexDirection:'row',justifyContent:'space-between',marginLeft: 20}}>
              <Text style ={{color:'red' , marginTop:3, marginStart: 10}}>***** 4.5</Text>
              <Text style ={{color:'red' , marginTop:3, marginStart: 10}}>45 Min</Text>
              <Text style ={{color:'red' , marginTop:3, marginStart: 10}}>23 Km</Text>
              </View>
              </View>


              </View>

          <View style={{borderBottomWidth:0.2 , marginTop:20}}></View>


      


        </View>
      );

      const renderItem = ({ item }) => (
        <Item title={ item.title} id={ item.id} droplocation={item.droplocation} dropplace={item.dropplace} />
     
      );

    StatusBar.setHidden(true);

  

   
  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>


      <ScrollView>
      <View style = {{height:80 , backgroundColor:'#F87300' , borderBottomLeftRadius:0 , borderBottomRightRadius:0  }}>
      <Image style={{ marginTop:15 , marginBottom:0,width: 112, height: 47,marginLeft:75 }} source={require('../../assets/icons/tallo-logo-main.png')} />
      <TouchableOpacity  onPress={()=>navigate('signUp')}>
<Image style={{ marginTop:-40 , marginBottom:0, width: 42, height: 42,marginLeft:15 }} source={require('../../assets/Images/BackButton.png')} />
  </TouchableOpacity>
      </View>

        <View style={styles.container}>         
        <View style = {styles.imageAvater}>                
          <TouchableOpacity style={styles.uploadImageBtn} onPress={() => _signUp()}>
         </TouchableOpacity>                       
                                  
          </View>
   
        </View>
  
 
     <View style = {{ marginBottom:0 , borderWidth:0.5 , backgroundColor:'#fff' , padding:10 , margin:14 , borderRadius:15}}>
    {/* <Text style = {{fontSize:20 ,  marginBottom:15}}>Primary Details</Text> */}
   
   


   
  
    <FlatList
      data={pickupdata}
      renderItem={renderItem}
      keyExtractor={item => item.id}
    />




  
    </View>



      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
        
        // justifyContent: "center",
    },
    title: {
        fontSize: 16,
        color:'gray',
        marginTop:10
      },
      title1: {
        fontSize: 16,
        color:'black',
        fontWeight:'bold',
      },
      item: {
        backgroundColor: '#fff',
        padding: 5,
        // marginVertical: 8,
        // marginHorizontal: 16,
        marginBottom:20
      },

});