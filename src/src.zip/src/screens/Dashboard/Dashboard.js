import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    View, Dimensions,
    Image, Modal,
    TextInput,
    TouchableOpacity,
    Switch,
    PermissionsAndroid
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { Card, IconButton, Colors, Button } from 'react-native-paper';
import { useDispatch ,useSelector} from 'react-redux'
import StaticText from '../../utils/StaticText'
import { navigate, navigateScreen } from '../../Tools/NavigationServices'
import { getItemFromStorage,saveToStorage} from "../../utils/AccessStorage";
import MapView from "react-native-maps";

import Geolocation from '@react-native-community/geolocation';
import { getDefaultLocale } from "react-datepicker";

const origin = { latitude: 13.082680, longitude: 80.270721 };


export default function Dashboard({ navigation }) {
  const user_info = useSelector((state) => state.SignIn.User_info);
  const [region, setRegion] = useState({
    latitude: 13.082680,
    longitude: 80.270721,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01
});
const [mark, setMark] = useState([
    {
        latitude: 13.082680,
        longitude: 80.270721,
    },
    {
        latitude: 12.932063,
        longitude: 79.333466,
    },
]);
    const dispatch = useDispatch();
    const [name, setname] = useState(0);
    const [image, setimage] = useState(0);
    const [currentLongitude,setCurrentLongitude ] = useState('...');
    const [currentLatitude,setCurrentLatitude] = useState('...');
    const [locationStatus,setLocationStatus ] = useState('');
    const [rider_id,setRiderId ] = useState('');

  
    

    React.useEffect(() => {
        const requestLocationPermission = async () => {
         
            if (Platform.OS === 'ios') {
              getOneTimeLocation();
              subscribeLocationLocation();
            } else {
              try {
                const granted = await PermissionsAndroid.request(
                  PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
                  {
                    title: 'Location Access Required',
                    message: 'This App needs to Access your location',
                  },
                );
                if (granted === PermissionsAndroid.RESULTS.GRANTED) {
                  //To Check, If Permission is granted
                  getOneTimeLocation();
                // subscribeLocationLocation();
                } else {
                  setLocationStatus('Permission Denied');
                }
              } catch (err) {
                console.warn(err);
              }
            }
          };
          requestLocationPermission();
          getdata()
         
          const unsubscribe  = navigation.addListener("focus", () =>
          refreshPage()
        );
        return () => {
          // clean up event listener
          unsubscribe
        }
        
        
        // Execute the created function directly
       // anyNameFunction();
      }, []);

      async function getdata(){
        var id = await getItemFromStorage("RiderId")
        if(id!=""){
          dispatch({type:'GET_RIDER_DETAILS',params:id})
        }
        setRiderId(id)
        setname(user_info.full_name)
        // setimage( "https://www.tallo.in/dev/uploads/riders/"+user_info.profile_image)
      }

      function refreshPage(){
        getOneTimeLocation();
      }
    
      const getOneTimeLocation = () => {
        setLocationStatus('Getting Location ...');
        Geolocation.getCurrentPosition(
          //Will give you the current location
          (position) => {
            setLocationStatus('You are Here');
            console.log("Position...........",position);
            //getting the Longitude from the location json
            const currentLongitude = 
              JSON.stringify(position.coords.longitude);
    
            //getting the Latitude from the location json
            const currentLatitude = JSON.stringify(position.coords.latitude);
               saveToStorage("CurrentLat",position.coords.latitude.toString())
               saveToStorage("CurrentLon",position.coords.longitude.toString())
            //Setting Longitude state
            setCurrentLongitude(currentLongitude);
            
            //Setting Longitude state
            setCurrentLatitude(currentLatitude);
          
         
        
         
              riderUpdateLocation()
           
      
    //         fetch('https://maps.googleapis.com/maps/api/geocode/json?address=' + position.coords.latitude + ',' + position.coords.longitude + '&key=' + "AIzaSyB79IrJjGiy5oFOtgfTltYJk5rUVdp63vA")
    //         .then((response) => response.json())
    //         .then((responseJson) => {
             
               
    //             var address = responseJson.results[0].address_components[0].long_name +","+  responseJson.results[0].address_components[2].long_name +","+responseJson.results[0].address_components[3].long_name+","+ responseJson.results[0].address_components[5].long_name +","+ responseJson.results[0].address_components[6].long_name+","+ responseJson.results[0].address_components[7].long_name
    //             setAddress(address)
    //             console.log("Addess",address.toString())
               
    
    // })
    
                },

               

                
          
          (error) => {
            setLocationStatus(error.message);
          },
          {
            enableHighAccuracy: false,
            timeout: 30000,
           maximumAge: 60000
          },
        );
      };

    async function riderUpdateLocation(){
      const interval = setInterval(() => {
        riderUpdateLocation1()
        console.log('Logs every minute');
      }, 30000);
    
      return () => clearInterval(interval);

       
      }

      async function riderUpdateLocation1(){
       
          console.log("in the function")
          var id = await getItemFromStorage("RiderId")
          console.log(id)
          var lat = await getItemFromStorage("CurrentLat")
          var lon = await getItemFromStorage("CurrentLon")
             var request = {
                "rider_id":id,
                "lat": parseFloat(lat),
                "lon":parseFloat(lon),
                "online_status":"1"
            }
              dispatch({type:'RIDER_UPDATE_LOCATION',payload:request})
        }
      
    
      
    
      const subscribeLocationLocation = () => {
        watchID = Geolocation.watchPosition(
          (position) => {
            //Will give you the location on location change
            
            setLocationStatus('You are Here');
           // console.log("Position...........",position);
    
            //getting the Longitude from the location json        
            const currentLongitude =
              JSON.stringify(position.coords.longitude);
    
            //getting the Latitude from the location json
            const currentLatitude = 
              JSON.stringify(position.coords.latitude);
    
            //Setting Longitude state
            setCurrentLongitude(currentLongitude);
            saveToStorage("CurrenLat",currentLatitude)
            //Setting Latitude state
            setCurrentLatitude(currentLatitude);
            saveToStorage("CurrentLon",currentLongitude)
          },
          (error) => {
            setLocationStatus(error.message);
          },
          {
            enableHighAccuracy: false,
            maximumAge: INFINITY
          },
        );
      };



   function navigaterider(){
   // navigate('RiderOngoingRide')
     if(currentLatitude!="" && currentLongitude!=""){
        navigation.navigate('RiderStatusOnline', { lat: currentLatitude, 
          lon:currentLongitude })
     }
   }

    
        function _signUp() {
           navigate('RiderOngoingRide')
            // var request = {
             
            //   "phone": "1234567890",
            //   "navigation": navigation
            // }
            // dispatch({ type: 'DASHBOARD', payload: request })
          }
        

   

    return (
        <ScrollView>
        <View style={styles.container}>
        {/* <MapView
                style={{ flex: 1 }}
                region={region}
                onRegionChangeComplete={region => setRegion(region)}
            >
                {mark.map((coordinate, index) =>
                    <MapView.Marker key={`coordinate_${index}`} coordinate={coordinate} />
                )}
              
            </MapView> */}
{/* <MapView.Marker key={`coordinate_1`} coordinate={origin} /> */}

            <View style={{ flex: 1, textAlign: 'center', margin: 3, justifyContent: 'space-between', marginBottom: 2 }}>

            <Card style={{ backgroundColor: 'white', marginTop: 0 }}>
                <View style={{marginTop:5,justifyContent:'center',alignItems:'center'}}>
                <Image style={{ width: 127, height: 27 }} source={require('../../assets/Images/MadeInIndia.png')} />
                    </View>
            
           

                <View style={{ backgroundColor: '#ffe6e6', height: 50, borderWidth: 0, marginBottom: 3, borderRadius: 15, flexDirection: 'row', justifyContent: 'space-between', padding: 10,marginTop:20 }}>
                    

                <View style={{borderWidth:1,borderRadius:1,borderColor:'white',backgroundColor:'#F67321'}}>
                <Image style={{ width: 30, height: 30 }} source={require('../../assets/Images/Online2.png')} />
                    </View>

                  
                    <TouchableOpacity onPress={()=>
                    navigaterider()}> 
                    
                    <Image style={{ width: 30, height: 25 }} source={require('../../assets/Images/Online.png')} />
                    </TouchableOpacity>

                   
                    <Image style={{ width: 40, height:30 }} source={require('../../assets/Images/GoTo1.png')} />
                   
                </View>

                <View style={{  marginBottom: 15, flexDirection: 'row', justifyContent: 'space-between', padding: 1 }}>
                <Text style={{ fontSize: 13, color: '#F67321', fontWeight: 'bold',marginLeft:8 }}>Offline</Text>
                    <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold',marginLeft:1 }}>Online</Text>
                   
                    <View style={{  marginBottom: 0, flexDirection: 'column', padding: 1 ,marginRight: 10}}>
    <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginRight: 0 }}>Go To</Text>
    <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginLeft: 0}}>Home</Text>
</View>
    </View>
   
  
  

</Card>


                <Card style={{ borderRadius: 20, backgroundColor: 'white', marginTop: 380 }}>

                <View style={{ flexDirection: 'row',justifyContent: 'space-between',marginRight: 10 , marginTop: 10 }}>
<View>
                <View style={{   marginBottom: 5, flexDirection: 'row', padding: 1,marginLeft: 10  }}>
<Image style={{ width: 20, height: 25,marginLeft: 10,marginRight: 1,marginTop: 1,marginBottom: 1 }} source={require('../../assets/Images/Rating.png')} />
<Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold',marginLeft: 10,marginTop: 5 }}>4.5</Text>
</View>

<Card.Content style={{ flexDirection: 'row',marginLeft: 1,marginBottom: 20 }}>
<Image style={{ width: 40, height: 45 }} source={{uri : image ? image :require('../../assets/Images/photo.png')}} />
    <View style={{ flexDirection: 'column' }}>
        <Text style={{ fontWeight: 'bold', fontSize: 16, marginStart: 10 }}>{name}</Text>
        <Text style={{ fontWeight: 'normal',color: 'grey', fontSize: 11, marginStart: 10, marginTop: 1 }}>Basic Level</Text>
    </View>
</Card.Content>
</View>



                <View style={{   marginBottom: 5, flexDirection: 'column', justifyContent: 'space-between', padding: 1 }}>
<Image style={{ width: 10, height: 10,marginRight: 1,marginTop: 20,marginBottom: 1,marginLeft: 45}} source={require('../../assets/Images/Path.png')} />

<View style={{ flexDirection: 'column', padding: 1 }}>    
<Text style={{ fontWeight: 'normal',color: 'grey',  fontSize: 11,marginLeft: 15 }}>Earnings</Text>
             <Text style={{ fontWeight: 'bold', fontSize: 15, }}>₹5,470.00</Text>
             </View>

</View>   
</View>
                </Card>
            </View>
        </View >
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f3f3f3',
        justifyContent: 'center',
        // alignItems: 'center'
    },
    buttongender: {
        color: '#000', marginTop: 10,
        fontSize: 14, textAlign: 'center', fontWeight: 'bold'
    },
    buttontext: {
        color: '#fff',
        fontSize: 16, fontWeight: 'bold'
    },
    loginBtn: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#fec750",
    },
    cancel: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#8f8f8f",
    },
    centeredView: {
        marginTop: 150
    },
    modalView: {
        margin: 20,
        height: 200,
        backgroundColor: "white",
        borderRadius: 20,
        // padding: 35,
        // alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
    customRatingBarStyle: {
        justifyContent: 'center',
        flexDirection: 'row',
        // marginTop: 30,
    },
    starImageStyle: {
        width: 25,
        height: 25,
        resizeMode: 'cover',
    },
    input: {
        backgroundColor: '#fbfbfb',
        textAlignVertical: 'top',
        marginTop: 10,
        height: 80,
        marginLeft: 20, marginRight: 20,
        borderColor: '#f3f3f3',
        borderWidth: 1,
    },
});