import React, { useState } from 'react'
import {
  View,
  Button, Text,
  TextInput, TouchableOpacity,
  StyleSheet, Image , FlatList,
  StatusBar
} from 'react-native'
import { getStoreValue } from '../../Tools/StoreHandler'
import { useDispatch } from 'react-redux'
import { getItemFromStorage } from '../../utils/AccessStorage'
import { Images } from '../../utils'
import Appicon from "../../components/Appicon";
import { ScrollView } from 'react-native-gesture-handler'
import AntDesign from 'react-native-vector-icons/AntDesign';
import { navigate, navigateScreen } from '../../Tools/NavigationServices'

export default function Language({ navigation }) {
  const dispatch = useDispatch();


  const [btnDisabled, setbtnDisabled] = useState(true)
  const [itemId, setitemId] = useState("")
  const [imgLink, setimgLink] = useState("")
  const [itemindex, setitemindex] = useState("")
  
  StatusBar.setHidden(true);

  const RiderID = "Rider Id:TA26354"

  const primaryData = [
    {
      
      id: '1',
      title: 'English',
    },
    {
      id: '2',
      title: 'Tamil',
    },
    {
      id: '3',
      title: 'Telugu',
    },

    {
      id: '4',
      title: 'Hindi',
    },
    {
      id: '5',
      title: 'Kaanada',
    },
    {
        id: '6',
        title: 'Malayalam',
      },

  ];



 

  React.useEffect(() => {

    
  }, []);

  

  const renderItem = ({ item }) =>{
    return (
        <TouchableOpacity onPress={() => { PressedItem(item.id, item.title), setitemindex(item.id) }} >
            <View style={itemindex == item.id ? styles.SelectedlistItem : styles.listItem} >
                
            <TouchableOpacity style={{  marginLeft: 15, borderRadius: 3 }}
                   >
<Text style = {{fontSize:20 , color:'grey', marginBottom:5 , marginTop:4,marginLeft:5}}>{ item.title}</Text>
                </TouchableOpacity>
            </View>
        </TouchableOpacity>
    )
}

const PressedItem = (itemId, itemImg) => {
  console.log(itemId)
  setitemId(itemId)
  setbtnDisabled(false)
  setimgLink(itemImg)
 
}
  



  function _signUp() {
    var request = {
    
      "navigation": navigation
    }
    dispatch({ type: 'CHOOSE_LANUAGE', payload: request })
  }



  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>


      <ScrollView>
     
  
           
<View style = {{ marginTop:-60 , marginBottom:100 ,marginLeft:0,height:5,flexDirection: 'column',justifyContent: 'space-around'}}>
  
            <Image style={{ width: '100%', height: 390, alignSelf: 'center' }} source={require('../../assets/Images/Rectangle.png')} /> 
<View style = {{ marginTop:1 , marginBottom:100 ,marginLeft:0,height:5,flexDirection: 'row'}}>



  <Image style={{ marginTop:60 , marginBottom:0, width: 112, height: 47,marginLeft:75 }} source={require('../../assets/icons/tallo-logo-main.png')} />
</View>
  </View>

  <TouchableOpacity  onPress={()=>navigate('signUp')}>
<Image style={{ marginTop:-20 , marginBottom:0, width: 42, height: 42,marginLeft:15 }} source={require('../../assets/Images/BackButton.png')} />
  </TouchableOpacity>

  <Text style = {{fontSize:20 , color:'#ffffff', marginBottom:25 , marginTop:100,marginLeft:45}}>Choose Language</Text>

 
  <View>
   

<FlatList
                        data={primaryData}
                        renderItem={renderItem}
                       
                        keyExtractor={item => item.id.toString()}

                    />



         <TouchableOpacity style={styles.loginBtn} onPress={() => _signUp()}>
                <Text style={styles.buttontext}>Confirm</Text>
              </TouchableOpacity> 

    </View>
    
    <View style={{position: 'absolute', //Here is the trick
    bottom: 0,left:10}}>
                    <Image style={{ width: 162, height: 35,marginLeft:2 }} source={require('../../assets/Images/MadeInIndia.png')} />
</View>

      </ScrollView>
    </View>
  )
}

const renderItem = ({ item }) => (
  <Item title={item.title} />
);



const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection:'row'
  },
  buttongender: {
    color: 'white',
    // padding:20,
    paddingTop: 5,
    paddingBottom: 5,
    fontSize: 12, 
    textAlign: 'center',
  },

  logintext: {
    marginTop:0,
    padding: 3,
    marginLeft: 0,
    color: '#000000',
    fontSize: 18,
    alignItems:'center',
    alignContent:'center',
    justifyContent:'center'
  },


  imageAvater:{
    paddingVertical: 30,
    padding:30,
    width: 80,
    marginStart:20,
    height: 80,
    // flexDirection:'row',
    // borderRadius: 150/2,
    // marginLeft:40,
    backgroundColor:'#fff',
    borderWidth:1,
    // borderStyle: 'dashed',
    margin:20
   },
   uploadImageBtn: {
    borderRadius: 5,
    height: 35,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    marginTop:30
  },
    item: {
    backgroundColor: '#fff',
    padding: 5,
    // marginVertical: 8,
    // marginHorizontal: 16,
  },
  title: {
    fontSize: 20,
    color:'gray'
  },
  title1: {
    fontSize: 24,
    color:'black',
    fontWeight:'bold',
  },
  loginBtn: {
    borderRadius: 5,
    height: 35,
    marginLeft: 50,
    marginRight: 60,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    marginTop: 100,
    backgroundColor: "#F87300",
    marginBottom:100
  },
  buttontext: {
    color: '#fff',
    fontSize: 16, fontWeight: 'bold'
  },
  listItem: {
    backgroundColor:"#fff", 
    marginBottom:-15 , padding:5 , margin:14 , borderRadius:15, marginTop:10,
  
},

SelectedlistItem: {
    backgroundColor:"#F87300", marginBottom:-10 , padding:1 , margin:14 , borderRadius:15, marginTop:10,
    width: 190,
    height:45
},
  
})