import React, { useState } from 'react'
import {
  View,
  Button, Text,
  TextInput, TouchableOpacity,ToastAndroid,
  StyleSheet, Image ,StatusBar,Alert
} from 'react-native'
import { getStoreValue } from '../../Tools/StoreHandler'
import { useDispatch } from 'react-redux'
import { getItemFromStorage } from '../../utils/AccessStorage'
import { Images } from '../../utils'
import Appicon from "../../components/Appicon";
import { ScrollView } from 'react-native-gesture-handler'
import AntDesign from 'react-native-vector-icons/AntDesign';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import AsyncStorage from '@react-native-community/async-storage';
import { navigate, navigateScreen } from '../../Tools/NavigationServices'

 import ImgToBase64 from 'react-native-image-base64';

//import * as ImagePicker from 'react-native-image-picker';

export default function License({ navigation }) {
  const dispatch = useDispatch();

  const [LisenceNo, setLisenceNo] = useState("")
  const [Imagefront, setImagefront] = useState("")
  const [Imageback, setImageback] = useState("")
  const [filePathFront, setFilePathFront] = useState({})
  const [filePathBack, setFilePathBack] = useState({})

  StatusBar.setHidden(true);
  // React.useEffect(() => {
    
  //   // Create an scoped async function in the hook
  //   async function anyNameFunction() {
  //     const GetDetails = await getItemFromStorage('PhoneNumber')
  //     if (!GetDetails) { }
  //     else { SetPhone(GetDetails) }

  //   }
  //   // Execute the created function directly
  //   anyNameFunction();
  // }, []);

 

 

const chooseFile1 = (type,str) => {
  let options = {
    mediaType: type,
    maxWidth: 300,
    maxHeight: 550,
    quality: 1,
    
  };
  launchImageLibrary(options, (response) => {
  console.log('Response = ', response);

  // if (response.didCancel) {
  //   alert('User cancelled camera picker');
  //   return;
  // } else if (response.errorCode == 'camera_unavailable') {
  //   alert('Camera not available on device');
  //   return;
  // } else if (response.errorCode == 'permission') {
  //   alert('Permission not satisfied');
  //   return;
  // } else if (response.errorCode == 'others') {
  //   alert(response.errorMessage);
  //   return;
  // }
  // console.log('base64 -> ', response.base64);
  // console.log('uri -> ', response.uri);
  // console.log('width -> ', response.width);
  // console.log('height -> ', response.height);
  // console.log('fileSize -> ', response.fileSize);
  // console.log('type -> ', response.type);
  // console.log('fileName -> ', response.fileName);
  if(str=="front"){
    setFilePathFront(response.uri)
    setImagefront(response.uri)
   
  
  }else{
    setFilePathBack(response.uri)
    setImageback(response.uri)
   
  }
  //setFilePath(response);
});
}

  function _signUp(str) {
   // Alert.alert('hi')
    chooseFile1("Image",str)
    
  }

  

  function _signUp1() {
  
  

  //  ImgToBase64.getBase64String(filePathFront) // Image URL
  //   .then(
  //       (base64String) => {
  //           console.log(base64String);
  //           setFilePathFront(base64String) // "iVBORw0KGgoAAAANSwCAIA..."
  //       }
  //   )
  //   .catch(
  //       (error) => {
  //           console.log(error); // Logs an error if there was one
  //       }
  //   )

  //   ImgToBase64.getBase64String(filePathBack) // Image URL
  //   .then(
  //       (base64String) => {
  //           console.log(base64String);
  //           setFilePathBack(base64String) // "iVBORw0KGgoAAAANSwCAIA..."
  //       }
  //   )
  //   .catch(
  //       (error) => {
  //           console.log(error); // Logs an error if there was one
  //       }
  //   )
   
  if(LisenceNo == ""){
    ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
   }else if(Imagefront == "" ){
    ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
   }else if(Imageback== ""){
    ToastAndroid.showWithGravity("Please enter the details",ToastAndroid.LONG, ToastAndroid.CENTER);
   }else{
  
  var request = {
      "LisenceNo": LisenceNo,
      "FrontImage": filePathFront,
      "BackImage": filePathBack,
      "navigation": navigation
    }
    dispatch({ type: 'DRIVING_LICENSE', payload: request })
  }
  }

  

  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>

      <ScrollView>
      {/* <View style = {{height:130 , backgroundColor:'#F87300'  }}>
      <Appicon icon={require("../../assets/icons/tallo-logo-main.png")} />
      </View> */}


          
<View style = {{ marginTop:1 , marginBottom:140 ,marginLeft:0,height:5,flexDirection: 'column',justifyContent: 'space-around'}}>
            <Image style={{ width: 470, height: 200, alignSelf: 'center' }} source={require('../../assets/Images/Pathlogo.png')} />
            {/* <Image style={{ marginTop:0 , marginBottom:0, width: 102, height: 40,marginLeft:45 }} source={require('../../assets/icons/tallo-logo-main.png')} /> */}
            {/* <Text style = {{fontSize:20 , fontWeight:'bold' ,color:'#ffffff', marginBottom:5 , marginTop:100}}>Choose Language</Text> */}
                     
<View style = {{ marginTop:1 , marginBottom:50 ,marginLeft:0,height:5,flexDirection: 'row'}}>
  {/* <Image style={{ marginTop:0 , marginBottom:0, width: 32, height: 30,marginLeft:5 }} source={require('../../assets/Images/BackButton.png')} /> */}
  

  <Image style={{ marginTop:-30 , marginBottom:0, width: 112, height: 47,marginLeft:80 }} source={require('../../assets/icons/tallo-logo-main.png')} />
  
</View>
<TouchableOpacity  onPress={()=>navigate('Language')}>
<Image style={{ marginTop:10 , marginBottom:0, width: 42, height: 42,marginLeft:15 }} source={require('../../assets/Images/BackButton.png')} />
  </TouchableOpacity>

  </View>

        <View style={styles.container}>
          
          <View style={{ textAlign: 'left' }}>
            <Text style={[styles.logintext, { color: '#000000', fontFamily: 'Montserrat-Bold' }]}>Driving Licence</Text>
            <View style={{ marginTop: 10 }}>
          
               <TextInput
                style={styles.input}
                //value={LisenceNo}
                placeholder='Licence Number*'
                autoCapitalize="none"
                placeholderTextColor="#808080"
                onChangeText={(mobile) => setLisenceNo(mobile)}
              />


                     {/* <View style = {styles.imageAvater}>
                                
                     <TouchableOpacity style={styles.uploadImageBtn} onPress={() => _signUp("front")}>{
                     filePathFront !="" ? 
                     <Image
                     source={{uri: filePathFront.uri}}
                     style={styles.imageAvater1}
                   />:<View> <AntDesign name="upload" size={30} color="#808080" />
                   <Text style={styles.uploadtext}>Upload Licence(Front)</Text></View>}
                       </TouchableOpacity>
                       </View> */}
                       
        
              {/* <View style = {styles.imageAvater}>
                                
                 <TouchableOpacity style={styles.uploadImageBtn} onPress={() => _signUp("front")}>
                   {
                     filePathFront ? 
                     <Image
                     source={{uri: filePathFront.uri}}
                     style={styles.imageAvater}
                   />:
                   <View>
                  <AntDesign name="upload" size={30} color="#808080" />
                <Text style={styles.uploadtext}>Upload Licence(Front)</Text></View>
                   }
                     
               
              </TouchableOpacity>
              
                                
               </View> */}
                {
                     Imagefront != ""? 
                     <View style = {styles.imageAvater}>
                                
                     <TouchableOpacity style={styles.uploadImageBtn1} onPress={() => _signUp("front")}>
                     <Image
                     source={{uri: Imagefront}}
                     style={{width: 270,height: 150}}
                   />
                       </TouchableOpacity>
                       </View>:
                        <View style = {styles.imageAvater}>
                                
                        <TouchableOpacity style={styles.uploadImageBtn} onPress={() => _signUp("front")}>
                        <AntDesign name="upload" size={30} color="#808080" />
                        <Text style={styles.uploadtext}>Upload Licence(Front)</Text>
                          </TouchableOpacity>
                          </View>} 

                          {
                     Imageback  ? 
                     <View style = {styles.imageAvater}>
                                
                     <TouchableOpacity style={styles.uploadImageBtn1} onPress={() => _signUp("back")}>
                     <Image
                     source={{uri: Imageback}}
                     style={{width: 270,height: 150}}
                   />
                     
                       </TouchableOpacity>
                       </View>:
                        <View style = {styles.imageAvater}>
                                
                        <TouchableOpacity style={styles.uploadImageBtn} onPress={() => _signUp("back")}>
                        <AntDesign name="upload" size={30} color="#808080" />
                <Text style={styles.uploadtext}>Upload Licence(Back)</Text>
                      
                          </TouchableOpacity>
                          </View>} 
                           {/* <View style = {styles.imageAvater}>
                                
                 <TouchableOpacity style={styles.uploadImageBtn} onPress={() => _signUp("back")}>
                     <AntDesign name="upload" size={30} color="#808080" />
                <Text style={styles.uploadtext}>Upload Licence(Back)</Text>
              </TouchableOpacity>
              
                                
               </View> */}
                            

                        


               
         
               <TouchableOpacity style={styles.loginBtn} onPress={() => _signUp1()}>
                <Text style={styles.buttontext}>Confirm</Text>
              </TouchableOpacity> 
            </View>
          </View>

        </View>
   
      </ScrollView>
    </View>
  )
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  input: {
    width: 330,
    height: 40,
    marginLeft: 20,
    marginRight: 5,
    marginBottom: 20,
    padding: 5,
    color: '#000',
    fontSize: 16,
    borderColor: "black",
    borderWidth: 0.5,
    borderRadius:10,
    
    
    
  },
  logintext: {
    padding: 0,
    marginLeft: 25,
    color: '#000000',
    fontSize: 20,
    marginTop:0
  },
  period: {
    borderRadius: 5,
    borderColor: '#fff',
    borderWidth: 1,

    marginHorizontal: 5,
  },
  periodActive: {
    backgroundColor: '#333',
  },

  loginBtn: {
    borderRadius: 10,
    height: 40,
    marginLeft: 50,
    marginRight: 60,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    marginTop: 20,
    backgroundColor: "#F87300",
    marginBottom:0
  },

  uploadImageBtn: {
    borderRadius: 5,
    height: 35,
    // marginLeft: 50,
    // marginRight: 60,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    // marginTop: 40,
    // backgroundColor: "#F87300",
    marginTop:50
  },
  uploadImageBtn1: {
    borderRadius: 5,
    height: 35,
    // marginLeft: 50,
    // marginRight: 60,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    // marginTop: 40,
    // backgroundColor: "#F87300",
    marginTop:40
  },
  imageAvater:{
   paddingVertical: 30,
   padding:50,
   width: 290,
   height: 170,
   borderRadius: 7,
   marginLeft:40,
   backgroundColor:'#fff',
   borderWidth:1,
   borderStyle: 'dashed',
   margin:10
  },
  imageAvater1:{
   // paddingVertical: 30,
   // padding:40,
    width: 300,
    height: 180,
   //borderRadius: 7,
    marginLeft:10,
    //backgroundColor:'#fff',
    //borderWidth:1,
    //borderStyle: 'dashed',
    margin:5
   },
  buttontext: {
    color: '#fff',
    fontSize: 16, fontWeight: 'bold'
  },
    uploadtext: {
    color: '#808080',
    fontSize: 16, fontWeight: 'bold',
    marginTop:5
  },
  buttongender: {
    // color: '#fff',
    // padding:20,
    paddingTop: 5,
    paddingBottom: 5,
    fontSize: 12, textAlign: 'center',
  },
})