import React, { useState } from 'react'
import {
  View,
  Button, Text,
  TextInput, TouchableOpacity,
  StyleSheet, Image , StatusBar
} from 'react-native'
import { getStoreValue } from '../../Tools/StoreHandler'
import { useDispatch,useSelector} from 'react-redux'
import { getItemFromStorage } from '../../utils/AccessStorage'
import { Images } from '../../utils'
import Appicon from "../../components/Appicon";
import { ScrollView } from 'react-native-gesture-handler'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import StaticText from '../../utils/StaticText'


export default function RiderDetails({ navigation }) {
  const dispatch = useDispatch();
  const user_info = useSelector((state) => state.SignIn.User_info.rider_info);

   // const users = useSelector((state) => state.SignIn.data);
   // const User_info = useSelector((state) => state.User_info);
    console.log("++++++++++++++HI+++++++++++",user_info)
  const [RiderId, setRiderId] = useState("")
  const [Name, setName] = useState("")
  const [Date, setDate] = useState("")
  const [Email, setEmail] = useState("")
  const [City, setCity] = useState("")
  const [Gender, setGender] = useState("")
  const [Aadhar, setAadhar] = useState("")
  const [VehicleNo, setVehicleNo] = useState("")
  const [License, setLicense] = useState("")
  const [PanNO, setPanNO] = useState("")

  StatusBar.setHidden(true);
  React.useEffect(() => {
    dispatch({type:'GET_RIDER_DETAILS',params:StaticText.RiderId})
    setRiderId(user_info.id)
    
    setCity(user_info.city)
    setName(user_info.full_name)
    setDate(user_info.dob)
    setEmail(user_info.email)
    setPanNO(user_info.PCNo)
     setAadhar(user_info.aadharcard_number)
    setVehicleNo(user_info.vehicle_no)
    setGender(user_info.gender)
    setLicense(user_info.driving_license_number)
    setPanNO(user_info.pancard_number)
    // Create an scoped async function in the hook
    async function anyNameFunction() {
      const GetDetails = await getItemFromStorage('PhoneNumber')
      if (!GetDetails) { }
      else { SetPhone(GetDetails) }

    }
    // Execute the created function directly
   // anyNameFunction();
  }, []);


  function _signUp() {
    var request = {
      "Name": Name,
      "Date": Date,
      "Email": Email,
      "City": City,
      "gender": Gender,
     
      "navigation": navigation
    }
    dispatch({ type: 'RIDER_DETAILS', payload: request })
  }


  



  return (
    <View style={{ flex: 1, backgroundColor: '#fff' ,marginBottom:"1%" }}>

      <ScrollView>

        <View style={styles.container}>
                       
                            <View style = {{flexDirection:'row' , marginTop:20}} >
                            <Image style={{ marginTop:0 , marginBottom:0, width: 92, height: 92,marginLeft:15 }} source={require('../../assets/Images/photo.png')} /> 
<View style = {{flexDirection:'column' , marginTop:20}} >
<Text style = {{marginRight:8 , fontSize:23, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>Rider Id :{RiderId}</Text>
<Text style = {{marginRight:8 , fontSize:23, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>{Name}</Text>
                            </View>
                            </View>
                            

                           
<View style={{ marginTop: 27 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 350, width: 340, borderRadius: 5}}>
<Text style = {{marginRight:8 , fontSize:20, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>Primary Details</Text>
            <View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>Full Name</Text>
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>{Name}</Text>
                            </View>
                           
                            <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 0.2, width: 300, borderRadius: 5}}>
          </View>
                            <View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>Date Of Birth</Text>
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>{Date}</Text>
                            </View>

                            <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 0.2, width: 300, borderRadius: 5}}>
          </View>

                            <View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>Mail Id</Text>
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>{Email}</Text>
                            </View>

                            <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 0.2, width: 300, borderRadius: 5}}>
          </View>

                            <View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>City</Text>
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>{City}</Text>
                            </View>

                            <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 0.2, width: 300, borderRadius: 5}}>
          </View>

                            <View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>Gender</Text>
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>{Gender}</Text>
                            </View>
          </View>
          <Text style = {{marginRight:8 , fontSize:20, marginLeft: 15,marginTop: 20,fontWeight: 'bold', }}>Required Documents</Text>

                   <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 75, width: 340, borderRadius: 5}}>
                   <View style = {{flexDirection:'column' , marginTop:20}} >
                   <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>Adhar</Text>
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>{Aadhar} </Text>
                            </View> 
                   </View>  

                   <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 75, width: 340, borderRadius: 5}}>
<View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>Vehicle Number</Text>
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>{VehicleNo}</Text>
                            </View>
                   </View>  

                   <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 75, width: 340, borderRadius: 5}}>
                   <View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>Driving Licence</Text>
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>{License}</Text>
                            </View>
                   </View>  

                    
                   <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 75, width: 340, borderRadius: 5}}>
                   <View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>PAN Number</Text>
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>{PanNO}</Text>
                            </View>
                   </View> 


                   <View style={{ marginTop: 7 ,marginBottom: 1, marginLeft: 10 ,borderColor: 'grey',borderWidth: 0.3,height: 75, width: 340, borderRadius: 5}}>
                   <View style = {{flexDirection:'column' , marginTop:20}} >
                            <Text style = {{marginRight:8 , fontSize:14, marginLeft: 15,marginTop: 0,fontWeight: 'bold', }}>Insurence Number</Text>
                            <Text style = {{marginRight:8 , fontSize:13, marginLeft: 15,marginTop: 0 }}>{PanNO}</Text>
                            </View>
                   </View> 

                   <TouchableOpacity style={styles.loginBtn} onPress={() => _signUp()} >
                        <Text style={styles.buttontext}>Done</Text>
                    </TouchableOpacity>   
        </View>
       
      </ScrollView>
    </View>
  )
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
   

    marginBottom:"1%"
  },
  input: {
    width: 300,
    height: 40,
    marginLeft: 15,
    marginRight: 15,
    marginBottom: 20,
    padding: 5,
    color: '#000',
    fontSize: 16,
    borderColor: "#d9d9d9",
    borderWidth: 0.5,
  },
  logintext: {
    padding: 5,
    marginLeft: 10,
    color: '#000000',
    fontSize: 22,
  },
  period: {
    borderRadius: 5,
    borderColor: '#fff',
    borderWidth: 1,

    marginHorizontal: 5,
  },
  periodActive: {
    backgroundColor: '#333',
  },

  loginBtn: {
    borderRadius: 5,
    height: 39,
    width:320,
    marginLeft: 19,
    marginRight: 60,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    marginTop: 30,
    backgroundColor: "#F87300",
    marginBottom:"5%"
  },
  buttontext: {
    color: '#fff',
    fontSize: 16, fontWeight: 'bold'
  },
  buttongender: {
    color: '#fff',
    // padding:20,
    paddingTop: 5,
    paddingBottom: 5,
    fontSize: 12, textAlign: 'center',
  },
})