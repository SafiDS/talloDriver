import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    View, Dimensions,
    Image, Modal,
    TextInput,
    TouchableOpacity,
    Switch,ActivityIndicator
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { Card, IconButton, Colors, Button } from 'react-native-paper';
import { navigate, navigateScreen } from '../../Tools/NavigationServices'
import { getItemFromStorage } from "../../utils/AccessStorage";
import { useDispatch,useSelector} from "react-redux";
import { StaticText } from "../../utils";
import MapView from "react-native-maps";



export default function RiderGoToHome({ navigation }) {
    const dispatch = useDispatch();
    // const users1 = useSelector((state) => state.SignIn.bookingInfo);
    // console.log("booking_info+++",users1)

   
    const [pickupLocation, setpickupLocation] = useState("");
    const [dropLocation, setdropLocation] = useState("");
   
    const [booking_id, setBookingid] = useState("")
    const [rider_id, setriderid] = useState("")
    const [mark, setMark] = useState(
        { latitude: 0, longitude: 0 } );
    const [origin, setorigin] = useState({ latitude: 13.082680, longitude: 80.270721 });
   
    const [region, setRegion] = useState({
        latitude: 13.082680,
        longitude: 80.270721,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01
    });
    const [snapPoints, setsnapPoints] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [lat, setlat] = useState("");
    const [long, setlong] = useState("");


   

    React.useEffect(() => {
    
    
        // Create an scoped async function in the hook
        async function anyNameFunction() {
         
          const booking_id = await getItemFromStorage('Booking_Id')
          const rider_id = await getItemFromStorage('RiderId')
          const latt = await getItemFromStorage('CurrenLat')
          const lon = await getItemFromStorage('CurrenLon')
            if(booking_id!=null){
              setBookingid(booking_id)
              var request = {
         
                "booking_id": booking_id
              }
              dispatch({type:'BOOKING_INFO',payload:request})
            }

            setriderid(rider_id)
            
            setlat(parseFloat(latt))
            setlong(parseFloat(lon))
         
             setMark({latitude:lat,longitude:long})
             setorigin({latitude:lat,longitude:long})
             
             setRegion({latitude:lat,longitude:long,latitudeDelta:0.01,longitudeDelta:0.01})
           const src = await getItemFromStorage('source')
           const des = await getItemFromStorage('destination')
           setpickupLocation(src)
           setdropLocation(des)
         }
        anyNameFunction();
       
      
        const unsubscribe  = navigation.addListener("focus", () =>
        refreshPage()
      );
      return () => {
        // clean up event listener
        unsubscribe
      }

    
        // Execute the created function directly
       }, []);

       
       function refreshPage() {
        var request = {
         
            "booking_id": booking_id
          }
          dispatch({type:'BOOKING_INFO',payload:request})
        // if(users1!=null || users1!=undefined){
        //     setpickupLocation(users1.source)
        //     setdropLocation(users1.destination)
        // }
      
       }

       function bookAccept(){
           var request = {
            "booking_id":booking_id,
            "rider_id":rider_id,
            "navigation": navigation
            }

        dispatch({type:'RIDER_BOOKING_ACCEPT',payload:request})
       }
    
    
  

    return (
       
        <View style={styles.container}>
             <MapView
            style={{ flex: 1 }}
            zoomEnabled={true}
          region={region}
      onRegionChangeComplete={region => setRegion(region)}
  >
      
     
     <MapView.Marker key={`coordinate_1`} coordinate={origin} />
      
  </MapView>
          
            <View style={{ flex: 1, width:'95%', margin: 10, justifyContent: 'space-between', marginBottom: 2 ,position:'absolute',top:10}}>


         

                <View style={{ marginTop: 20,backgroundColor: '#ffe6e6', height: 50, borderWidth: 0, marginBottom: 3, borderRadius: 15, flexDirection: 'row', justifyContent: 'space-between', padding: 10,}}>
                  

                <TouchableOpacity onPress={()=>navigate('Dashboard')}> 
                <Image style={{ width: 30, height: 25 }} source={require('../../assets/Images/Online2.png')} />
                    </TouchableOpacity>

                   
                    <View style={{borderWidth:1,borderRadius:1,borderColor:'white',backgroundColor:'green'}}>
                    <Image style={{ width: 30, height: 25 }} source={require('../../assets/Images/Online.png')} />
                    </View>
                  
                    <View >
                    <Image style={{ width: 40, height:30 }} source={require('../../assets/Images/GoTo1.png')} />
                    </View>
                </View>

                <View style={{  marginBottom: 5, flexDirection: 'row', justifyContent: 'space-between', padding: 1 }}>
                <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginLeft: 9,}}>Offline</Text>
                <Text style={{ fontSize: 13, color: 'green', fontWeight: 'bold',marginLeft: 0 ,marginRight: 8 }}>Online</Text>
                <View style={{  marginBottom: 0, flexDirection: 'column', padding: 1,marginLeft: 0 }}>
    <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginRight: 10 }}>Go To</Text>
    <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginLeft: 0}}>Home</Text>
</View>
    </View>


    <Image style={{ width: 30, height:30,marginLeft: 310 ,marginTop: 170 }} source={require('../../assets/Images/droplocations.png')} />

<View style={{ backgroundColor: '#000000', height: 80,borderColor: "#FF9900",borderWidth: 2,marginTop: 10,borderRadius:5 }}>
            <Text style={{ color: '#ffffff', fontSize: 11, alignItems: 'center', justifyContent: 'center', fontWeight: 'bold',marginLeft: 10, marginTop: 10}}>New Ride
</Text>
            <Text style={{ color: 'grey', fontWeight: 'bold', fontSize: 10, marginBottom: 1, alignItems: 'center', justifyContent: 'center',marginLeft: 10 , marginTop: 4}}> You have new ride new you home location.</Text>
            <Text style={{ color: 'grey', fontWeight: 'bold', fontSize: 10, marginBottom: 0, alignItems: 'center', justifyContent: 'center',marginLeft: 10 , marginTop: 4}}> Can you pickup?

</Text>

</View>

</View>

                <Card style={{ borderRadius: 20,width:'95%', backgroundColor: 'white',position:'absolute',bottom:10,margin:10 }}>


                <View style={{   marginBottom: 5, flexDirection: 'row',justifyContent: 'space-between', padding: 1,marginLeft: 10  }}>
                <Text style={{ fontSize: 16, color: '#FF9900', fontWeight: 'bold',marginLeft: 5,marginTop: 5 }}>Hey! you have new ride </Text>
                <Image style={{ width: 20, height: 20,marginRight: 1,marginTop: 5,marginBottom: 1,marginLeft: 1,marginRight: 10 }} source={require('../../assets/Images/dropdown.png')} />
</View>


                <View style={{ flexDirection: 'row',justifyContent: 'space-between',marginRight: 10 , marginTop: 1 }}>
<View>
             

<Card.Content style={{ flexDirection: 'row',marginLeft: 1,marginBottom: 20 , marginTop: 5}}>
<Image style={{ width: 40, height: 45 }} source={require('../../assets/Images/photo.png')} />
        <Text style={{ fontWeight: 'bold', fontSize: 16, marginStart: 10 }}>Mike Daniel</Text>
</Card.Content>
</View>

</View>



<View style={{  marginBottom: 0, flexDirection: 'row',  padding: 1 }}>
              

<View style={{ flexDirection: 'column', marginStart: 8, }}>
<Image style={{ width: 16, height: 16,marginTop: 10, marginStart: 0 }} source={require('../../assets/Images/Path2.png')} />
<Image style={{ width: 5, height: 38,marginTop: 0, marginStart: 5 }} source={require('../../assets/Images/Path3.png')} />
<Image style={{ width: 18, height: 22,marginTop: 0, marginStart: 0 }} source={require('../../assets/Images/Path1.png')} />
</View>  

<View style={{ flexDirection: 'column', padding: 0, marginStart: 10,marginTop: 10, }}>    

<View style={{ flexDirection: 'column', padding: 1, marginStart: 1 }}>    
<Text style={{ fontWeight: 'normal',color: 'grey', fontSize: 9, marginStart: 1, marginTop: 1 }}>Pickup Location</Text>
<Text style={{ fontWeight: 'bold', fontSize: 13, marginStart: 1 }}>{pickupLocation}</Text>
</View>
             
<View style={{ flexDirection: 'column', padding: 1, marginStart: 1,marginTop: 17 }}>    
<Text style={{ fontWeight: 'normal',color: 'grey', fontSize: 9, marginStart: 1, marginTop: 1 }}>Drop Location</Text>
<Text style={{ fontWeight: 'bold', fontSize: 13, marginStart: 1 }}>{dropLocation}</Text>
             </View>

             </View>
  
    </View>



<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 20 }}>
                    <TouchableOpacity style={styles.loginBtnn}
                    >
                        <Text style={styles.buttontextt}>Decline</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.loginBtn} 
                  onPress={bookAccept}
                    >
                        <Text style={styles.buttontext}>Accept</Text>
                    </TouchableOpacity>
                </View>
                </Card>
           
        </View >
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f3f3f3',
        justifyContent: 'center',
        // alignItems: 'center'
    },
    buttongender: {
        color: '#000', marginTop: 10,
        fontSize: 14, textAlign: 'center', fontWeight: 'bold'
    },
    buttontext: {
        color: '#fff',
        fontSize: 14, fontWeight: 'bold'
    },
    buttontextt: {
        color: '#000000',
        fontSize: 14,
        fontWeight: 'bold'
    },
    loginBtn: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        width: 110,
        marginLeft: 10,
        marginRight: 5,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#F87300",
        marginTop: 5,
        marginBottom: 30

    },
    loginBtnn: {
        width: 180,
        borderRadius: 5,
        borderColor: "#ff8000",
        borderWidth: 1,
        height: 35,
        marginLeft: 10,
        marginRight: 1,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        marginTop: 10,
        backgroundColor: "#fff",
        color: "#000000",
        marginBottom: "10%"
    },
    cancel: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#8f8f8f",
    },
    centeredView: {
        marginTop: 150
    },
    modalView: {
        margin: 20,
        height: 200,
        backgroundColor: "white",
        borderRadius: 20,
        // padding: 35,
        // alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
    customRatingBarStyle: {
        justifyContent: 'center',
        flexDirection: 'row',
        // marginTop: 30,
    },
    starImageStyle: {
        width: 25,
        height: 25,
        resizeMode: 'cover',
    },
    input: {
        backgroundColor: '#fbfbfb',
        textAlignVertical: 'top',
        marginTop: 10,
        height: 80,
        marginLeft: 20, marginRight: 20,
        borderColor: '#f3f3f3',
        borderWidth: 1,
    },
});