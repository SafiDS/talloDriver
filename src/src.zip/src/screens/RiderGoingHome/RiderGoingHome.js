import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    View, Dimensions,
    Image, Modal,
    TextInput,
    TouchableOpacity,
    Switch
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { Card, IconButton, Colors, Button } from 'react-native-paper';
import { navigate, navigateScreen } from '../../Tools/NavigationServices'
import MapView from "react-native-maps";
import MapViewDirections from 'react-native-maps-directions'
import { useDispatch } from "react-redux";

export default function RiderGoingHome({ route,navigation }) {

    const dispatch = useDispatch();
    const [mark, setMark] = useState(
        { latitude: 0, longitude: 0 } );
    const [origin, setorigin] = useState({ latitude: 13.082680, longitude: 80.270721 });
    const [destination, setdestination] = useState({ latitude: 0, longitude: 0 })
    const [region, setRegion] = useState({
        latitude: 13.082680,
        longitude: 80.270721,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01
    });
    const [snapPoints, setsnapPoints] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [lat, setlat] = useState("");
    const [long, setlong] = useState("");
    const [message, setMessage] = useState("")
    const [ridemessage, setrideMessage] = useState("")
    const GOOGLE_MAPS_APIKEY = 'AIzaSyB79IrJjGiy5oFOtgfTltYJk5rUVdp63vA';

    React.useEffect(() => {
   
        var lat = route.params.lat
        var lon = route.params.lon

        console.log(lat , lon)
    
       setlat(parseFloat(lat))
       setlong(parseFloat(lon))
    
        setMark({latitude:parseFloat(lat),longitude:parseFloat(lon)})
        setorigin({latitude:parseFloat(lat),longitude:parseFloat(lon)})
        
        setRegion({latitude:parseFloat(lat),longitude:parseFloat(lon),latitudeDelta:0.01,longitudeDelta:0.01})
        

        
        }, []);

    return (
       
        <View style={styles.container}>
             <MapView
style={{ flex: 1 }}
 zoomEnabled={true}
    region={region}
      onRegionChangeComplete={region => setRegion(region)}
  >
      {console.log(destination)}
     
     <MapView.Marker key={`coordinate_1`} coordinate={origin} />
      
  </MapView>
            <View style={{ flex: 1, textAlign: 'center', margin: 20, justifyContent: 'space-between', marginBottom: 20 }}>

         


                <View style={{ backgroundColor: '#fff', height: 50, borderWidth: 0, marginBottom: 30, borderRadius: 15, flexDirection: 'row', padding: 10 }}>
                    <Image style={{ width: 20, height: 20 }} source={require('../../assets/Images/locations.png')} />
                    <Text style={{ fontSize: 16, color: '#000000', fontWeight: '500',marginLeft: 15,fontWeight: 'bold' }}>Enter Home Address</Text>

                </View>


               
                    <Card.Content style={{ marginTop: 520  }}>
      

<TouchableOpacity style={styles.loginBtn}  onPress={()=>navigate('RiderGoToHome')} >
                <Text style={styles.buttontext}>Confirm to Home</Text>
            </TouchableOpacity>

                    </Card.Content>
              

            </View>

        </View >
       
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f3f3f3',
        justifyContent: 'center',
        // alignItems: 'center'
    },
    buttongender: {
        color: '#000', marginTop: 10,
        fontSize: 14, textAlign: 'center', fontWeight: 'bold'
    },
    buttontext: {
        color: '#fff',
        fontSize: 16,
         fontWeight: 'bold'
    },
    loginBtn: {
        borderRadius: 10,
        height: "55%",
        marginLeft: 3,
        marginRight: 0,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        marginTop: 1,
        backgroundColor: "#F87300",
        marginBottom:10,
    },
    cancel: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#8f8f8f",
    },
    centeredView: {
        marginTop: 150
    },
    modalView: {
        margin: 20,
        height: 200,
        backgroundColor: "white",
        borderRadius: 20,
        // padding: 35,
        // alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
    customRatingBarStyle: {
        justifyContent: 'center',
        flexDirection: 'row',
        // marginTop: 30,
    },
    starImageStyle: {
        width: 25,
        height: 25,
        resizeMode: 'cover',
    },
    input: {
        backgroundColor: '#fbfbfb',
        textAlignVertical: 'top',
        marginTop: 10,
        height: 80,
        marginLeft: 20, marginRight: 20,
        borderColor: '#f3f3f3',
        borderWidth: 1,
    },
});