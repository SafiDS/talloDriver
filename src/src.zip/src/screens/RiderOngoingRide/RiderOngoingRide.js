import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    View, Dimensions,
    Image, Modal,
    TextInput,
    TouchableOpacity,
    Switch,
    Model
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { Card, IconButton, Colors, Button } from 'react-native-paper';
import { navigate, navigateScreen } from '../../Tools/NavigationServices';
import { useDispatch,useSelector } from "react-redux";
import { getItemFromStorage } from "../../utils/AccessStorage";
import MapView from "react-native-maps";
import MapViewDirections from 'react-native-maps-directions';

export default function RiderOngoingRide({ navigation }) {
    const dispatch = useDispatch();
    const users1 = useSelector((state) => state.SignIn.bookingInfo);
    console.log("booking_info+++",users1)


    const [coupon, setCoupon] = useState("")
    const [mode, setMode] = useState("")
    const [SourceLat,setSourceLat] = useState("")
    const [SourceLong,setSourceLong] = useState("")
    const [DesLat,setDesLat] = useState("")
    const [DesLong,setDesLong] = useState("")
    const [Source,setSource] = useState("")
    const [Destination,setDestination] = useState("")
    const [user_id,setUserId] = useState("")
    const [vehicle_id,setVehicleId] = useState("")
    const [booking_otp,setBookingOtp] = useState("")
    const [distance,setDistance] = useState("")
    const [total_price,setTotalPrice] = useState("")
    const [time,setTime] = useState("")
    const [BookingId,setBookingId] = useState("")
    const [booking_id, setBookingid] = useState("")

    const [Status,setStatus] = useState("")
    const [rider_id, setriderid] = useState("")
    const [modalVisible, setModalVisible] = useState(false);
        
    const [mark, setMark] = useState(
        { latitude: 0, longitude: 0 } );
    const [origin, setorigin] = useState({ latitude: 13.082680, longitude: 80.270721 });
    const [destination, setdestination] = useState({ latitude: 0, longitude: 0 })
    const [region, setRegion] = useState({
        latitude: 13.082680,
        longitude: 80.270721,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01
    });
    const [snapPoints, setsnapPoints] = useState(false);
    const [RaidDetails, setRaidDetails] = useState(false);
    const snap_Points = snapPoints ? ["30%", "30%"] : ["30%", "50%"]
    const GOOGLE_MAPS_APIKEY = 'AIzaSyB79IrJjGiy5oFOtgfTltYJk5rUVdp63vA';
    React.useEffect(() => {
   
        var lat = users1.source_lat
        var lon = users1.source_lon
    
        var latd = users1.destination_lat
        var lond = users1.destination_lon
    
        setMark({latitude:parseFloat(lat),longitude:parseFloat(lon)})
        setorigin({latitude:parseFloat(lat),longitude:parseFloat(lon)})
        console.log("_____origin_____",origin)
        setdestination({latitude:parseFloat(latd),longitude:parseFloat(lond)})
        setRegion({latitude:parseFloat(lat),longitude:parseFloat(lon),latitudeDelta:0.01,longitudeDelta:0.01})
         setUserId(users1.user_id)
         setVehicleId(users1.vehicle_id)
         setBookingId(users1.booking_id)
         setSource(users1.source)
        
         setDestination(users1.destination)
         
         setSourceLat(parseFloat(users1.source_lat))
         setSourceLong(parseFloat(users1.source_lon))
         setDesLat(parseFloat(users1.destination_lat))
         setDesLong(parseFloat(users1.destination_lon))
         setMode(users1.payment_mode)
         setCoupon(users1.coupon_code)
         setBookingOtp(users1.booking_otp)
         setDistance(users1.distance)
         setStatus(users1.status)
         //setTime(booking_info.)
         setTotalPrice(users1.total_price)
         console.log(origin)

         async function anyNameFunction() {
         const rider_id = await getItemFromStorage('RiderId')
         const booking_id = await getItemFromStorage('Booking_Id')

              if(rider_id!=null){
                setriderid(rider_id)
                setBookingid(booking_id)

              } 
           }
        
         anyNameFunction();
        }, []);
     
     
        function collectCash() {
      
           navigate('SuccessScreen');
           setModalVisible(!modalVisible);
          }

    function _signUp() {
       
        // var request = {
            
        //         "booking_id":booking_id,
        //         "rider_id":rider_id,
        //         "destination":Destination,
        //         "destination_lat":DesLat,
        //         "destination_lon":DesLong,
        //         "navigation": navigation
        //         }
         
        // console.log(Destination)
        // console.log(DesLat)

        // console.log(DesLong)

        // dispatch({ type:'RIDER_BOOKING_COMPLETE', payload: request })
        setModalVisible(true)
      }

   
    return (
        <View style={styles.container}>
               <Modal
        animationType="slide"
        transparent={false}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          setModalVisible(!modalVisible);
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
         
          <TouchableOpacity onPress={() => setModalVisible(false)}>
           <Image style={{ marginRight:20 ,marginTop:20 , marginBottom:0, width: 15, height: 15,marginLeft:270 }} source={require('../../assets/Images/Cancel2.png')} />
           </TouchableOpacity>
            
           <View style={{ marginBottom: 0, padding: 20, margin: 1 }}>
         <View style={{  justifyContent: 'center', alignItems: 'center' }}>
                        <Image style={{ width: 50, height: 50 }} source={require('../../assets/Images/Scooty.png')} />
                <Text style={{ fontSize: 20, alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', marginBottom: 25,marginTop: 50 }}>Destination Arrived</Text>
                <View style={{  borderRadius: 15, borderWidth: 2.5, borderColor: '#ff8000',  marginBottom: 6, width: 150, height: 100 }}>
                <Text style={{ fontSize: 25, fontWeight: 'bold',marginTop: 20,marginLeft: 25 }}>₹ 152.00</Text>
                <Text style={{ color: 'gray', fontWeight: 'bold', fontSize: 13 ,marginLeft: 39}}> Cash Mode</Text>
</View>

<TouchableOpacity style={styles.loginBtn2} 

            onPress={() => collectCash() }
               >
                    <Text style={styles.buttontext}>Collect Cash</Text>
                </TouchableOpacity>
         </View>

     </View> 

          </View>
        </View>
      </Modal>
      
           

<MapView
style={{ flex: 1 }}

 zoomEnabled={true}
// showsCompass={true}
//showsBuildings={true}
//showsTraffic={true}
      region={region}
      onRegionChangeComplete={region => setRegion(region)}
  >
      {console.log(destination)}
      {/* {mark.map((coordinate, index) => {
          coordinate != null && coordinate != 0 ? */}
              <MapView.Marker key={`coordinate_`} coordinate={mark} />
              {/* :
              null
      }
      )} */}
      <MapView.Marker key={`coordinate_1`} coordinate={origin} />
      <MapView.Marker key={`coordinate_2`} coordinate={destination} />
      <MapViewDirections
          origin={origin}
          destination={destination}
          apikey={GOOGLE_MAPS_APIKEY}
          strokeWidth={3}
          strokeColor="hotpink"
          optimizeWaypoints={true}
          onStart={(params) => {
            console.log(`Started routing between "${params.origin}" and "${params.destination}"`);
          }}
          onReady={result => {
            console.log(`Distance: ${result.distance} km`)
            console.log(`Duration: ${result.duration} min.`)

           
        }}
      />
  </MapView>
  <View>
 

      </View>

  <Card style={{ borderRadius: 14, backgroundColor: 'white',position:'absolute',bottom:10,width:'95%',margin:10 }}>
                    <Card.Content style={{  }}>
      

<TouchableOpacity style={styles.loginBtn}
onPress={_signUp}
 >
                <Text style={styles.buttontext}>End Trip</Text>
            </TouchableOpacity>



                    </Card.Content>
                </Card> 


         
        </View >
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f3f3f3',
        justifyContent: 'center',
        // alignItems: 'center'
    },
    buttongender: {
        color: '#000', marginTop: 10,
        fontSize: 14, textAlign: 'center', fontWeight: 'bold'
    },
    buttontext: {
        color: '#fff',
        fontSize: 16,
         fontWeight: 'bold'
    },
    centeredView: {
        marginTop: 10
    },
    loginBtn2: {
        borderRadius: 5,
        height: "13%",
        width:"100%",
        marginLeft: 10,
        marginRight: 0,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        marginTop: 20,
        backgroundColor: "#F87300",
        marginBottom:"10%"
      },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 2
    },
    modalView: {
        margin: 4,
        backgroundColor: "white",
        borderRadius: 20,
        padding: 3,
        shadowColor: "#000",
        shadowOffset: {
          width: 0,
          height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
        //height:370,
        width:300
      },
    loginBtn: {
        borderRadius: 9,
        height: "50%",
        width:"100%",
        marginLeft: 3,
        marginRight: 0,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        marginTop: 5,
        backgroundColor: "#F87300",
        marginBottom:"10%"
    },
    cancel: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#8f8f8f",
    },
    
   
    customRatingBarStyle: {
        justifyContent: 'center',
        flexDirection: 'row',
        // marginTop: 30,
    },
    starImageStyle: {
        width: 25,
        height: 25,
        resizeMode: 'cover',
    },
    input: {
        backgroundColor: '#fbfbfb',
        textAlignVertical: 'top',
        marginTop: 10,
        height: 80,
        marginLeft: 20, marginRight: 20,
        borderColor: '#f3f3f3',
        borderWidth: 1,
    },
});