import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    View, Dimensions,
    Image, Modal,
    TextInput,
    TouchableOpacity,
    Switch,Pressable,
   
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { Card, IconButton, Colors, Button } from 'react-native-paper';
import { useDispatch } from 'react-redux'
import { navigate, navigateScreen } from '../../Tools/NavigationServices'
import MapView from "react-native-maps";
import MapViewDirections from 'react-native-maps-directions';

export default function RiderStatusOnline({route, navigation }) {
    const dispatch = useDispatch();
    const [mark, setMark] = useState(
        { latitude: 0, longitude: 0 } );
    const [origin, setorigin] = useState({ latitude: 13.082680, longitude: 80.270721 });
    const [destination, setdestination] = useState({ latitude: 0, longitude: 0 })
    const [region, setRegion] = useState({
        latitude: 13.082680,
        longitude: 80.270721,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01
    });
    const [snapPoints, setsnapPoints] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [lat, setlat] = useState("");
    const [long, setlong] = useState("");
    const [message, setMessage] = useState("")
    const [ridemessage, setrideMessage] = useState("")
    const GOOGLE_MAPS_APIKEY = 'AIzaSyB79IrJjGiy5oFOtgfTltYJk5rUVdp63vA';

    React.useEffect(() => {
   
        var lat = route.params.lat
        var lon = route.params.lon

        console.log(lat , lon)
    
       setlat(parseFloat(lat))
       setlong(parseFloat(lon))
    
        setMark({latitude:parseFloat(lat),longitude:parseFloat(lon)})
        setorigin({latitude:parseFloat(lat),longitude:parseFloat(lon)})
        
        setRegion({latitude:parseFloat(lat),longitude:parseFloat(lon),latitudeDelta:0.01,longitudeDelta:0.01})
        

        
        }, []);
     
    
    function _signUp() {
       
        var request = {
        //   "Name": Name,
        //   "Date": Date,
        //   "Email": Email,
        //   "City": City,
        //   "gender": Gender,
          "phone": "1234567890",
          "navigation": navigation
        }
       // dispatch({ type: 'RIDER_STATUS_ONLINE1', payload: request })
        setModalVisible(!modalVisible);
      }
  

    function uploadPhoto() {
        //    alert('Model was clos')
        if(lat!="" && long!=""){
            navigation.navigate('RiderStatusOnline1', { lat: lat, 
              lon:long })
         }
           //navigate('RiderStatusOnline1');
           setModalVisible(!modalVisible);
          }

    return (
        // <ScrollView>
        <View style={styles.container}>
            <MapView
style={{ flex: 1 }}
 zoomEnabled={true}
    region={region}
      onRegionChangeComplete={region => setRegion(region)}
  >
      {console.log(destination)}
     
     <MapView.Marker key={`coordinate_1`} coordinate={origin} />
      
  </MapView>

  <Card style={{ backgroundColor: 'white', top: 0 ,position:'absolute',width:'100%'}}>
           

           <View style={{marginTop:5,justifyContent:'center',alignItems:'center'}}>
                           <Image style={{ width: 127, height: 27 }} source={require('../../assets/Images/MadeInIndia.png')} />
                               </View>
           
                           <View style={{ backgroundColor: '#ffe6e6', height: 50, borderWidth: 0, marginBottom: 3, borderRadius: 15, flexDirection: 'row', justifyContent: 'space-between', padding: 10 , marginTop: 20}}>
           
           <TouchableOpacity onPress={()=>navigate('Dashboard')}> 
                           <Image style={{ width: 30, height: 25 }} source={require('../../assets/Images/Online2.png')} />
                               </TouchableOpacity>
           
                               <View style={{borderWidth:1,borderRadius:1,borderColor:'green',backgroundColor:'green'}}>
                               <Image style={{ width: 30, height: 25 }} source={require('../../assets/Images/Online.png')} />
                               </View>
                              
           
                               <Image style={{ width: 40, height:30 }} source={require('../../assets/Images/GoTo1.png')} />
                           </View>
           
                           <View style={{  marginBottom: 5, flexDirection: 'row', justifyContent: 'space-between', padding: 1 }}>
                           <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginLeft: 9,}}>Offline</Text>
                               <Text style={{ fontSize: 13, color: 'green', fontWeight: 'bold',marginLeft: 0 ,marginRight: 15 }}>Online</Text>
                              
                               
                               <View style={{  marginBottom: 0, flexDirection: 'column', padding: 1 ,marginRight: 10}}>
               <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginRight: 0 }}>Go To</Text>
               <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginLeft: 0}}>Home</Text>
           </View>
           
               </View>
             
            
           <View style={{alignItems: 'center',justifyContent: 'center', marginTop: 10}}>
               <Text style={{ fontSize: 13, color: 'green', fontWeight: 'bold' }}>You are now online</Text>
           
               <Text style={{ fontSize: 13, color: 'grey', fontWeight: 'bold' }}>You need to take photo and upload to</Text>
               <Text style={{ fontSize: 13, color: 'grey', fontWeight: 'bold' }}> our tallo team for the verification</Text>
           
           
           
               <TouchableOpacity style={styles.takePhoto}
                onPress={() => setModalVisible(true)}
              
                >
                           <Text style={styles.buttontext}>Take Photo</Text>
                       </TouchableOpacity>
                       </View>
           
           
           
           </Card>

           <Card style={{ borderRadius: 20, backgroundColor: 'white',position:'absolute',bottom:10,width:'95%',marginLeft:10 }}>

<View style={{ flexDirection: 'row',justifyContent: 'space-between',marginRight: 10 , marginTop: 10 }}>
<View>
<View style={{   marginBottom: 5, flexDirection: 'row', padding: 1,marginLeft: 10  }}>
<Image style={{ width: 20, height: 25,marginLeft: 10,marginRight: 1,marginTop: 1,marginBottom: 1 }} source={require('../../assets/Images/Rating.png')} />
<Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold',marginLeft: 10,marginTop: 5 }}>4.5</Text>
</View>

<Card.Content style={{ flexDirection: 'row',marginLeft: 1,marginBottom: 20 }}>
<Image style={{ width: 40, height: 45 }} source={require('../../assets/Images/photo.png')} />
<View style={{ flexDirection: 'column' }}>
<Text style={{ fontWeight: 'bold', fontSize: 16, marginStart: 10 }}>Johnatham</Text>
<Text style={{ fontWeight: 'normal',color: 'grey', fontSize: 11, marginStart: 10, marginTop: 1 }}>Basic Level</Text>
</View>
</Card.Content>
</View>



<View style={{   marginBottom: 5, flexDirection: 'column', justifyContent: 'space-between', padding: 1 }}>
<Image style={{ width: 10, height: 9,marginRight: 1,marginTop: 20,marginBottom: 1,marginLeft: 45}} source={require('../../assets/Images/Path.png')} />

<View style={{ flexDirection: 'column', padding: 1 }}>    
<Text style={{ fontWeight: 'normal',color: 'grey',  fontSize: 11,marginLeft: 15 }}>Earnings</Text>
<Text style={{ fontWeight: 'bold', fontSize: 15, }}>₹5,470.00</Text>
</View>

</View>   
</View>
</Card>

<Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          setModalVisible(!modalVisible);
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>

          <Text style={{ fontSize: 19, color: '#000000', fontWeight: 'bold', marginRight: 140}}>Upload Photo</Text>

          <View style = {styles.imageAvater}>
                            
                            <TouchableOpacity style={styles.uploadImageBtn} >
                               
                         </TouchableOpacity>
                         
                                           
      </View>
            <TouchableOpacity style={styles.changeImage} >
                <Text style={[styles.buttontext,{color:'red' , fontWeight:'100',marginTop:10,marginBottom: 10 }]}>Change Image</Text>
              </TouchableOpacity> 
              
              <TouchableOpacity style={[styles.uploadPhoto]} 
           
              onPress={() => uploadPhoto()}
              >
                <Text style={styles.buttontext}> Upload Photo </Text>
              </TouchableOpacity> 
             
          </View>
        </View>
      </Modal>
          
        </View > 
         
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f3f3f3',
        justifyContent: 'center',
        // alignItems: 'center'
    },
    buttongender: {
        color: '#000', marginTop: 10,
        fontSize: 14, textAlign: 'center', fontWeight: 'bold'
    },
    buttontext: {
        color: '#fff',
        fontSize: 16, fontWeight: 'bold',textAlign:'center',justifyContent:'center',
        marginBottom: 200
    },
    loginBtn: {
       // flex: 1,
        borderRadius: 5,
       height: 35,
        width: 610,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
       justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#F87300",
        marginTop: 15,
        marginBottom: 30

    },
    takePhoto: {
        // flex: 1,
         borderRadius: 5,
        height: 35,
         width: 170,
         marginLeft: 15,
         marginRight: 10,
         alignItems: "center",
        justifyContent: "center",
         textAlign: 'center',
         backgroundColor: "#F87300",
         marginTop: 15,
         marginBottom: 30
 
     },
    
    loginBtn1: {
        //flex: 1,
        borderRadius: 5,
        //height: 45,
        width: 210,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor:'white' , borderColor:'red' , borderWidth:1,
        marginTop: 15,
        marginBottom: 30

    },
    changeImage: {
        //flex: 1,
        borderRadius: 5,
        //height: 45,
        width: 210,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor:'white' , borderColor:'red' , borderWidth:1,
        marginTop: 5,
        marginBottom: 39

    },
    
    uploadPhoto: {
         // flex: 1,
         borderRadius: 5,
        height: 35,
         width: 170,
         marginLeft: 1,
         marginRight: 1,
         alignItems: "center",
        justifyContent: "center",
         textAlign: 'center',
         backgroundColor: "#F87300",
         marginTop: 15,
         marginBottom: 3
    },
    
    cancel: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#8f8f8f",
    },
    centeredView: {
        marginTop: 150
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22
      },
    modalView: {
        margin: 20,
        height: 200,
        backgroundColor: "white",
        borderRadius: 20,
        // padding: 35,
        // alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
       
    },
    customRatingBarStyle: {
        justifyContent: 'center',
        flexDirection: 'row',
        // marginTop: 30,
    },
    starImageStyle: {
        width: 25,
        height: 25,
        resizeMode: 'cover',
    },
    input: {
        backgroundColor: '#fbfbfb',
        textAlignVertical: 'top',
        marginTop: 10,
        height: 80,
        marginLeft: 20, marginRight: 20,
        borderColor: '#f3f3f3',
        borderWidth: 1,
    },
    modalView: {
        margin: 4,
        backgroundColor: "white",
        borderRadius: 20,
        padding: 35,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
          width: 0,
          height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5
      },
      button: {
        borderRadius: 20,
        padding: 10,
        elevation: 2
      },
      buttonOpen: {
        backgroundColor: "#F194FF",
      },
      buttonClose: {
        backgroundColor: "#2196F3",
      },
      textStyle: {
        color: "white",
        fontWeight: "bold",
        textAlign: "center"
      },
      modalText: {
        marginBottom: 15,
        textAlign: "center"
      }, imageAvater:{
        paddingVertical: 30,
        padding:10,
        width: 150,
        height: 150,
        // borderRadius: 150/2,
        // marginLeft:40,
        backgroundColor:'#fff',
        borderWidth:1,
        // borderStyle: 'dashed',
        margin:30
       }, 
       loginBtn: {
        borderRadius: 5,
        height: 35,
        marginLeft: 50,
        marginRight: 60,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        marginTop: 50,
        backgroundColor: "#F87300",
        marginBottom:30
      },
      buttontext: {
        color: '#fff',
        fontSize: 16, fontWeight: 'bold'
      },
      uploadImageBtn: {
        borderRadius: 5,
        height: 35,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        marginTop:30
      },
      uploadtext: {
        color: '#808080',
        fontSize: 16,
        marginTop:5
      },
});