import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    View, Dimensions,
    Image, Modal,
    TextInput,
    TouchableOpacity,
    Switch
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { Card, IconButton, Colors, Button } from 'react-native-paper';
import { useDispatch } from 'react-redux'
import { navigate, navigateScreen } from '../../Tools/NavigationServices'
import MapView from "react-native-maps";
import MapViewDirections from 'react-native-maps-directions'

export default function RiderStatusOnline1({route, navigation }) {

    const dispatch = useDispatch();
    const [mark, setMark] = useState(
        { latitude: 0, longitude: 0 } );
    const [origin, setorigin] = useState({ latitude: 13.082680, longitude: 80.270721 });
   
    const [region, setRegion] = useState({
        latitude: 13.082680,
        longitude: 80.270721,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01
    });
    const [snapPoints, setsnapPoints] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [lat, setlat] = useState("");
    const [long, setlong] = useState("");
    const [message, setMessage] = useState("")
    const [ridemessage, setrideMessage] = useState("")
    const GOOGLE_MAPS_APIKEY = 'AIzaSyB79IrJjGiy5oFOtgfTltYJk5rUVdp63vA';

    React.useEffect(() => {
   
        var lat = route.params.lat
        var lon = route.params.lon

        console.log(lat , lon)
    
       setlat(parseFloat(lat))
       setlong(parseFloat(lon))
    
        setMark({latitude:parseFloat(lat),longitude:parseFloat(lon)})
        setorigin({latitude:parseFloat(lat),longitude:parseFloat(lon)})
        
        setRegion({latitude:parseFloat(lat),longitude:parseFloat(lon),latitudeDelta:0.01,longitudeDelta:0.01})
        

        
        }, []);
     
        function Ridergoinghome() {
            //    alert('Model was clos')
            if(lat!="" && long!=""){
                navigation.navigate('RiderGoingHome', { lat: lat, 
                  lon:long })
             }
               //navigate('RiderStatusOnline1');
               setModalVisible(!modalVisible);
              }
        function _signUp() {
       
            var request = {
              "phone": "1234567890",
              "navigation": navigation
            }
            dispatch({ type: 'RIDER_GOTO_HOME', payload: request })
           // setModalVisible(!modalVisible);
          }


    return (
       
        <View style={styles.container}>
             <MapView
            style={{ flex: 1 }}
            zoomEnabled={true}
                region={region}
      onRegionChangeComplete={region => setRegion(region)}
  >
      
     
     <MapView.Marker key={`coordinate_1`} coordinate={origin} />
      
  </MapView>

  <Card style={{ backgroundColor: 'white', top: 0 ,position:'absolute',width:'100%'}}>
           


           <View style={{marginTop:5,justifyContent:'center',alignItems:'center', marginBottom: 10}}>
                           <Image style={{ width: 127, height: 27 }} source={require('../../assets/Images/MadeInIndia.png')} />
                               </View>
           
                           <View style={{ backgroundColor: '#ffe6e6', height: 50, borderWidth: 0, marginBottom: 3, borderRadius: 15, flexDirection: 'row', justifyContent: 'space-between', padding: 10 }}>
                               
                               
                           <TouchableOpacity onPress={()=>navigate('Dashboard')}> 
                           <Image style={{ width: 30, height: 25 }} source={require('../../assets/Images/Online2.png')} />
                               </TouchableOpacity>
           
                              
                               <View style={{borderWidth:1,borderRadius:1,borderColor:'white',backgroundColor:'#F67321'}}>
                               <Image style={{ width: 30, height: 25 }} source={require('../../assets/Images/Online.png')} />
                               </View>
           
                               <TouchableOpacity onPress={Ridergoinghome}> 
                               <Image style={{ width: 40, height:30 }} source={require('../../assets/Images/GoTo1.png')} />
                               </TouchableOpacity>
                           </View>
           
                           <View style={{  marginBottom: 5, flexDirection: 'row', justifyContent: 'space-between', padding: 1 }}>
                           <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginLeft: 9,}}>Offline</Text>
                           <Text style={{ fontSize: 13, color: 'green', fontWeight: 'bold',marginLeft: 0 ,marginRight: 8 }}>Online</Text>
                         
                           <View style={{  marginBottom: 0, flexDirection: 'column', padding: 1 ,marginRight: 10}}>
               <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginRight: 0 }}>Go To</Text>
               <Text style={{ fontSize: 13, color: '#000000', fontWeight: 'bold' ,marginLeft: 0}}>Home</Text>
           </View>
               </View>
           
           
           <View style={{alignItems: 'center',justifyContent: 'center'}}>
               <Text style={{ fontSize: 13, color: 'green', fontWeight: 'bold' }}>You are now online</Text>
           
               <Text style={{ fontSize: 13, color: 'grey', fontWeight: 'bold' }}>Yourphoto uploaded successfully. Please</Text>
               <Text style={{ fontSize: 13, color: 'grey', fontWeight: 'bold' }}>wait sometime for until responses from</Text>
               <Text style={{ fontSize: 13, color: 'grey', fontWeight: 'bold',marginBottom: 11 }}>our team</Text>
           
                       </View>
           
           
           
           </Card>

           <Card style={{ borderRadius: 20, backgroundColor: 'white',position:'absolute',bottom:10,width:'95%',marginLeft:10 }}>

<View style={{   marginBottom: 5, flexDirection: 'row',justifyContent: 'space-between', padding: 1,marginLeft: 10  }}>
<Text style={{ fontSize: 16, color: '#FF9900', fontWeight: 'bold',marginLeft: 10,marginTop: 5 }}>Hey! Mike wants to ride with you</Text>
<Image style={{ width: 20, height: 20,marginRight: 1,marginTop: 5,marginBottom: 1,marginLeft: 1}} source={require('../../assets/Images/dropdown.png')} />
</View>

<View style={{ flexDirection: 'row',justifyContent: 'space-between',marginRight: 10 , marginTop: 1 }}>
<View>

<Card.Content style={{ flexDirection: 'row',marginLeft: 1,marginBottom: 20 , marginTop: 5}}>
<Image style={{ width: 40, height: 45 }} source={require('../../assets/Images/photo.png')} />
<Text style={{ fontWeight: 'bold', fontSize: 13, marginStart: 10 }}>Mike Daniel</Text>
</Card.Content>
</View>

</View>


<View style={{  marginBottom: 0, flexDirection: 'row',  padding: 1 }}>


<View style={{ flexDirection: 'column', marginStart: 8 }}>
<Image style={{ width: 15, height: 15,marginTop: 0, marginStart: 8 }} source={require('../../assets/Images/Path2.png')} />
<Image style={{ width: 5, height: 34,marginTop: 0, marginStart: 12 }} source={require('../../assets/Images/Path3.png')} />
<Image style={{ width: 15, height: 17,marginTop: 0, marginStart: 7 }} source={require('../../assets/Images/Path1.png')} />
</View>  

<View style={{ flexDirection: 'column', padding: 1, marginStart: 10 }}>    

<View style={{ flexDirection: 'column', padding: 1, marginStart: 1 }}>    
<Text style={{ fontWeight: 'normal',color: 'grey', fontSize: 9, marginStart: 1, marginTop: 1 }}>Pickup Location</Text>
<Text style={{ fontWeight: 'bold', fontSize: 14, marginStart: 1 }}>123S 6th Crossman street , LA USA</Text>
</View>

<View style={{ flexDirection: 'column', padding: 1, marginStart: 1,marginTop: 7 }}>    
<Text style={{ fontWeight: 'normal',color: 'grey', fontSize: 9, marginStart: 1, marginTop: 1 }}>Drop Location</Text>
<Text style={{ fontWeight: 'bold', fontSize: 14, marginStart: 1 }}>34 , Norman road , Opp to Economics</Text>
<Text style={{ fontWeight: 'bold', fontSize: 14, marginStart: 1 }}>building, LA ,USA</Text>
</View>
</View>
</View>

<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 20 }}>
    <TouchableOpacity style={styles.loginBtnn}
    >
        <Text style={styles.buttontextt}>Decline</Text>
    </TouchableOpacity>
    <TouchableOpacity 
    style={styles.loginBtn} 
    onPress={() => navigate('RiderMultipleDestination')}
    >
        <Text style={styles.buttontext}>Accept</Text>
    </TouchableOpacity>
</View>
</Card>
           
        </View >
       
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f3f3f3',
        justifyContent: 'center',
        // alignItems: 'center'
    },
    buttongender: {
        color: '#000', marginTop: 10,
        fontSize: 14, textAlign: 'center', fontWeight: 'bold'
    },
    buttontext: {
        color: '#fff',
        fontSize: 16, fontWeight: 'bold'
    },
    loginBtn: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        width: 1,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#F87300",
        marginTop: 0,
        marginBottom: 30,
        width: 10,
    },
    loginBtnn: {
        width: 150,
        borderRadius: 5,
        borderColor: "#ff8000",
        borderWidth: 2,
        height: 35,
        marginLeft: 10,
        marginRight: 1,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        marginTop: 2,
        backgroundColor: "#fff",
        color: "#000000",
        marginBottom: "10%"
    },

    cancel: {
        flex: 1,
        borderRadius: 5,
        height: 35,
        marginLeft: 15,
        marginRight: 10,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        backgroundColor: "#8f8f8f",
    },
    centeredView: {
        marginTop: 150
    },
    modalView: {
        margin: 20,
        height: 200,
        backgroundColor: "white",
        borderRadius: 20,
        // padding: 35,
        // alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
    customRatingBarStyle: {
        justifyContent: 'center',
        flexDirection: 'row',
        // marginTop: 30,
    },
    starImageStyle: {
        width: 25,
        height: 25,
        resizeMode: 'cover',
    },
    input: {
        backgroundColor: '#fbfbfb',
        textAlignVertical: 'top',
        marginTop: 10,
        height: 80,
        marginLeft: 20, marginRight: 20,
        borderColor: '#f3f3f3',
        borderWidth: 1,
    },
});