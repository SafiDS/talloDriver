import React, { useState } from 'react'
import {
  View,
  Button, Text,
  TextInput, TouchableOpacity,
  StyleSheet, Image , StatusBar
} from 'react-native'
import { getStoreValue } from '../../Tools/StoreHandler'
import { useDispatch } from 'react-redux'
import { getItemFromStorage } from '../../utils/AccessStorage'
import { Images } from '../../utils'
import Appicon from "../../components/Appicon";
import { ScrollView } from 'react-native-gesture-handler'
import DropDownPicker from 'react-native-dropdown-picker';


export default function signUp({ navigation }) {
  const dispatch = useDispatch();

  const [Name, setName] = useState("")
  const [Date, setDate] = useState("")
  const [Email, setEmail] = useState("")
  const [City, setCity] = useState("")
  const [Vehicle, setVehicle] = useState("")
  const [Gender, setGender] = useState("")
  const [Phone, SetPhone] = useState("")
  const [pressed, setpressed] = useState(false)
  const [pressedon, setpressedon] = useState(false)

  StatusBar.setHidden(true);
  React.useEffect(() => {
    // Create an scoped async function in the hook
    async function anyNameFunction() {
      const GetDetails = await getItemFromStorage('PhoneNumber')
      if (!GetDetails) { }
      else { SetPhone(GetDetails) }

    }
    // Execute the created function directly
    anyNameFunction();
  }, []);


  function _signUp() {
    var request = {
      "Name": Name,
      "Date": Date,
      "Email": Email,
      "City": City,
      "Vehicle":Vehicle,
      "gender": Gender,
      "phone": Phone,
      "navigation": navigation
    }
    //alert(Vehicle)
    dispatch({ type: 'NEW_REGISTRATION', payload: request })
    

  }


  function selectGender(Status) {
    console.log(Status)
    if(Status=="Female"){
      setpressedon(!pressedon)
    }else{
      setpressed(!pressed)
    }
    setGender(Status)
  }



  return (
    <View style={{ flex: 1, backgroundColor: '#fff' ,marginBottom:"1%" }}>
<ScrollView>

     
    

        <View style={styles.container}>
          
         

                   
<View style = {{position: 'absolute', //Here is the trick
    top: 0,left:0,  marginBottom:100 ,height:5,flexDirection: 'column',justifyContent: 'space-around'}}>
            <Image style={{ width: 302, height: 280, alignSelf: 'center', }} source={require('../../assets/Images/loginshape.png')} />
            <Image style={{ marginTop:0 , marginBottom:0, width: 102, height: 40,marginLeft:15 }} source={require('../../assets/icons/tallo-logo-main.png')} />
  </View>


        
          <View style={{ textAlign: 'left' ,marginTop:"55%"}}>
            <Text style={[styles.logintext, { color: '#000000', fontFamily: 'Montserrat-Bold' }]}>Rider Registration</Text>
            <View style={{ marginTop: 20 }}>
              <TextInput
                style={styles.input}
                placeholder='Full Name*'
                autoCapitalize="none"
                placeholderTextColor="#d9d9d9"
                onChangeText={(mobile) => setName(mobile)}
              />
              <TextInput
                style={styles.input}
                placeholder='DD-MM-YYYY*'
                autoCapitalize="none"
                placeholderTextColor="#d9d9d9"
                onChangeText={(mobile) => setDate(mobile)}
              />
              <TextInput
                style={styles.input}
                placeholder='Mail id (optional)'
                autoCapitalize="none"
                placeholderTextColor="#d9d9d9"
                onChangeText={(mobile) => setEmail(mobile)}
              />
              <TextInput
                style={styles.input}
                placeholder='City*'
                autoCapitalize="none"
                placeholderTextColor="#d9d9d9"
                onChangeText={(mobile) => setCity(mobile)}
              />
               
<View style={{minHeight: 50}}>
          
             <DropDownPicker
               items={[
                {label: 'Bike', value: '1'},
                {label: 'Auto', value: '2'},
                {label: 'Car', value: '3'},
                {label: 'Commercial Vehicle', value: '4'},
            ]}
              // defaultValue={this.state.selected2}
               containerStyle={{height: 31}}
               placeholder="Vehicle*"
               style={{backgroundColor: '#fff',marginLeft:10,marginRight:9,borderColor:'#d9d9d9'}}
               placeholderStyle={{color: '#d9d9d9',fontSize:16}}
               itemStyle={{
                 justifyContent: 'flex-start',
               }}
               dropDownStyle={{backgroundColor: '#fff'}}
               onChangeItem={item => setVehicle(item.label) }
             />
        
         </View>
              <View style={{
                flexDirection: 'row', marginTop: 15, padding: 5,
                marginLeft: 15,
              }}>
                <Text style={{ textAlign: 'center', paddingTop: 5 }}>Gender*</Text>
                <TouchableOpacity style={{ backgroundColor: !pressed ? "#d9d9d9" : "#F87300", width: 70, marginLeft: 20, borderRadius: 3 }}
                  onPress={selectGender.bind(this, "Male")}
                >
                  <Text style={styles.buttongender}>Male</Text>
                </TouchableOpacity>
                <TouchableOpacity style={{  backgroundColor: !pressedon ? "#d9d9d9" : "#F87300", marginLeft: 10, width: 70, borderRadius: 3 }}
                  onPress={selectGender.bind(this, "Female")}
                >
                  <Text style={styles.buttongender}>Female</Text>
                </TouchableOpacity>

              </View>
              <TouchableOpacity style={styles.loginBtn} onPress={() => _signUp()}>
                <Text style={styles.buttontext}>Register</Text>
              </TouchableOpacity>
            </View>
          </View>

        </View>
        <View style={{ flexDirection: 'row',justifyContent: 'flex-end' }}>
        <Image style={{ marginTop:120 , width: 162, height: 35, marginRight:20}} source={require('../../assets/Images/MadeInIndia.png')} />

          {/* <Image style={{ bottom: 0 }}  source={Images["FootImage.png"]} /> */}
          <Image style={{ height:'100%' }} source={require('../../assets/Images/FootImage.png')} />

        </View>
        {/* <Image style={{ marginTop:1 , marginBottom:1, width: 162, height: 35,marginLeft:4 }} source={require('../../assets/Images/MadeInIndia.png')} /> */}
        </ScrollView>
    </View>
  )
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',

  },
  input: {
    width: 300,
    height: 30,
    marginLeft: 15,
    marginRight: 15,
    marginBottom: 20,
    padding: 5,
    color: '#000',
    fontSize: 16,
    borderColor: "#d9d9d9",
    borderWidth: 0.5,
  },
  input1: {
    width: 310,
   // height: 40,
    marginLeft: 10,
    marginRight: 10,
    marginBottom: 90,
    padding: 5,
    //color: '#000',
    fontSize: 16,
    // borderColor: "#d9d9d9",
    // borderWidth: 0.5,
  },
  logintext: {
    padding: 5,
    marginLeft: 10,
    color: '#000000',
    fontSize: 22,
  },
  period: {
    borderRadius: 5,
    borderColor: '#fff',
    borderWidth: 1,

    marginHorizontal: 5,
  },
  periodActive: {
    backgroundColor: '#333',
  },

  loginBtn: {
    borderRadius: 5,
    height: 35,
    marginLeft: 50,
    marginRight: 60,
    alignItems: "center",
    justifyContent: "center",
    textAlign: 'center',
    marginTop: 20,
    backgroundColor: "#F87300",
    //marginBottom:"10%"
  },
  buttontext: {
    color: '#fff',
    fontSize: 16, fontWeight: 'bold'
  },
  buttongender: {
    // color: '#fff',
    // padding:20,
    paddingTop: 5,
    paddingBottom: 5,
    fontSize: 12, textAlign: 'center',
  },
})