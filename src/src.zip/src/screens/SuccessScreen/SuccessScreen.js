import React, { useState } from "react";
import {
    StyleSheet,
    Text,
    View,
    TextInput,
    TouchableOpacity,
    Alert,
    Image,
    KeyboardAvoidingView,
     ScrollView,
     StatusBar,
     Modal
} from "react-native";
import { themes } from '../../utils'
import { useDispatch } from 'react-redux'
import { Button, Popup, Input } from '../../components'
// import Gender from "../../components/Gender";
import Appicon from "../../components/Appicon";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import Ionicons from 'react-native-vector-icons/Ionicons';
import { navigate, navigateScreen } from '../../Tools/NavigationServices';


export default function SuccessScreen({ navigation }) {
    const dispatch = useDispatch()
    const [mobile, setMobile] = useState("");
    const [check, setCheck] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);


    function _signUp() {
       
        var request = {
        //   "Name": Name,
        //   "Date": Date,
        //   "Email": Email,
        //   "City": City,
        //   "gender": Gender,
          "phone": "1234567890",
          "navigation": navigation
        }
       // dispatch({ type: 'RIDER_STATUS_ONLINE1', payload: request })
        setModalVisible(!modalVisible);
      }


    const refer  = "Refer your friend and earn rs 1000 for each"

    StatusBar.setHidden(true);

    function Signin() {
        

        dispatch({ type: 'LOGIN_REQUEST', payload: mobile })
    }
    function submitFeedback() {
      //    alert('Model was closed')
         navigate('RiderStatusOnline1');
         setModalVisible(!modalVisible);
        }


    return (
        <View style={styles.container}>
            <TouchableOpacity >
        <Image style={{ width: 40, height: 35, marginLeft: 300,marginTop: 20  }} source={require('../../assets/Images/Cancel.png')}  />
        </TouchableOpacity>
        <View style={{ marginBottom: 0, padding: 70, margin: 1 }}>
         <View style={{ marginLeft: 15, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                        <Image style={{ width: 190, height: 190, alignSelf: 'center' }} source={require('../../assets/Images/success.png')} />

             <Text style={{ fontSize: 25, alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', marginBottom: 25,marginTop: 30 }}>Payment Recieved</Text>

             <Text style={{ color: 'gray', fontWeight: 'bold', fontSize: 13 }}>Congratulation you have earned</Text>
             <Text style={{ color: 'gray', fontWeight: 'bold', fontSize: 13, marginBottom: 130, alignItems: 'center', justifyContent: 'center', }}> 152.00 rupees</Text>
         


             <TouchableOpacity style={styles.loginBtn} 
            //  onPress={() => navigate('RiderPayment')}
            onPress={() => setModalVisible(true)}
             
             >
                 <Text  style={styles.buttontext}>Continue</Text>
             </TouchableOpacity>
         </View>
        
          
             
     </View> 

     <Modal
        animationType="slide"
        transparent={false}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          setModalVisible(!modalVisible);
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
         
          
          <TouchableOpacity onPress={() => _signUp()}>
           <Image style={{ marginRight:20 ,marginTop:20 , marginBottom:0, width: 15, height: 15,marginLeft:270 }} source={require('../../assets/Images/Cancel2.png')} />
           </TouchableOpacity>
            
         
            
           <View style={{ marginBottom: 0, padding: 7, margin: 1 }}>
         <View style={{ marginLeft: 1, flexDirection: 'column',  }}>

         <View style={{ flexDirection: 'row', marginStart: 1 , justifyContent:'space-between',marginTop: 0 }}>
         <Text style={{ fontSize: 21,  fontWeight: 'bold', marginBottom: 0,marginTop: 0, marginStart: 0 }}>Rate Customer</Text>
         <TouchableOpacity onPress={() => _signUp()}>
           <Image style={{ marginRight:20 ,marginTop:0 , marginBottom:0, width: 15, height: 15,marginLeft:270 }} source={require('../../assets/Images/Cancel2.png')} />
           </TouchableOpacity>


</View>  

<View style={{  marginBottom: 0, flexDirection: 'row',  padding: 1, marginTop: 10  }}>
<View style={{ flexDirection: 'column', marginStart: 1 }}>
<Image style={{ width: 15, height: 15,marginTop: 0, marginStart: 0 }} source={require('../../assets/Images/Path2.png')} />
<Image style={{ width: 5, height: 50,marginTop: 0, marginStart: 5 }} source={require('../../assets/Images/Path3.png')} />
<Image style={{ width: 15, height: 17,marginTop: 0, marginStart: 0 }} source={require('../../assets/Images/Path1.png')} />
</View>  
<View style={{ flexDirection: 'column', padding: 1, marginStart: 4 }}>    
<View style={{ flexDirection: 'column', padding: 1, marginStart: 1 }}>    
<Text style={{ fontWeight: 'normal',color: 'grey', fontSize: 9, marginStart: 1, marginTop: 1 }}>Pickup Location</Text>
<Text style={{ fontWeight: 'bold', fontSize: 14, marginStart: 1,color: 'grey' }}>123S 6th Crossman street , LA USA</Text>
</View>
<View style={{ flexDirection: 'column', padding: 1, marginStart: 1,marginTop: 25 }}>    
<Text style={{ fontWeight: 'normal',color: 'grey', fontSize: 9, marginStart: 1, marginTop: 1 }}>Drop Location</Text>
<Text style={{ fontWeight: 'bold', fontSize: 14, marginStart: 1,color: 'grey' }}>34, Norman road, Opp to Economics</Text>
<Text style={{ fontWeight: 'bold', fontSize: 14, marginStart: 1,color: 'grey' }}>building, LA ,USA</Text>
             </View>
             </View>
  
    </View> 

<View  style={{ flexDirection: 'row', padding: 1, marginStart: 15,marginTop: 60 }} >
<Image style={{ width: 40, height: 40,marginTop: 0, marginStart: 6 }} source={require('../../assets/Images/Star.png')} />
    <Image style={{ width: 40, height: 40,marginTop: 0, marginStart: 6 }} source={require('../../assets/Images/Star.png')} />
    <Image style={{ width: 40, height: 40,marginTop: 0, marginStart: 6 }} source={require('../../assets/Images/Star.png')} />
    <Image style={{ width: 40, height: 40,marginTop: 0, marginStart: 6 }} source={require('../../assets/Images/Star.png')} />
    <Image style={{ width: 40, height: 40,marginTop: 0, marginStart: 6 }} source={require('../../assets/Images/Star.png')} />
</View>


<View  style={{  padding: 1, marginStart: 10,marginTop: 20 }} >

<TextInput
                style={styles.input}
                placeholder='Feedback'
                autoCapitalize="none"
                placeholderTextColor="#808080"
                onChangeText={(mobile) => setName(mobile)}
              />
</View>

   
             <TouchableOpacity style={styles.loginBtn}
                        //  onPress={() => navigate('RiderStatusOnline1')} 
                        onPress={() => submitFeedback()}
                            >
             
                 <Text style={styles.buttontext}>Submit Feedback</Text>
             </TouchableOpacity>
         </View>

     </View> 
          </View>
        </View>
      </Modal>

</View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
        height: '100%'
        
        // justifyContent: "center",
    },
    input: {
        width: 260,
        height: 90,
        marginLeft: 0,
        marginRight: 5,
        marginBottom: 20,
        padding: 5,
        color: '#000',
        fontSize: 16,
        borderColor: "black",
        borderWidth: 0.1,
        borderRadius:1,
      },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 2
      },
      modalView: {
        margin: 2,
        height: 510,
        backgroundColor: "white",
        borderRadius: 10,
        // padding: 35,
        // alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        width: 300
       
    },

    loginBtn: {
        borderRadius: 5,
        height: "10%",
        width:"100%",
        marginLeft: 0,
        marginRight: 0,
        alignItems: "center",
        justifyContent: "center",
        textAlign: 'center',
        marginTop: 10,
        backgroundColor: "#F87300",
        marginBottom:"0%"
      },
      buttontext: {
        color: '#fff',
        fontSize: 16, fontWeight: 'bold'
      },

});