import React from 'react'
import VerificationCode from './VerificationCode'
const VerificationCodeContainer = () => {
    return (
      <VerificationCode />
    )
  }

export default VerificationCodeContainer

