

const ImagesDetails = {

    // splash: require('../assets/Images/splash.png'),
    // carehealth: require('../assets/Images/carehealth.png'),
    LeftDesign: require('../assets/PNG/leftDesign.png'),
    RightDesign: require('../assets/PNG/RightDesign.png'),
    Logo: require('../assets/Images/logo.png'),
    Location: require('../assets/Images/Location.png'),
    car: require('../assets/Images/car.png'),
    bike: require('../assets/Images/bike.png'),
    auto: require('../assets/Images/auto.png'),
    delivery: require('../assets/Images/delivery.png'),
    ProfessionalServices: require('../assets/Images/ProfessionalServices.png'),
    errands: require('../assets/Images/errands.png'),
    // Logo: require('../assets/Images/zyter.png'),


}

export default ImagesDetails
