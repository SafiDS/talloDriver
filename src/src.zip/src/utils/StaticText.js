
const FreeText = {
  //Login page
  Login: 'Login',
  Username: 'Username',
  Password: 'Password',
  ForgotPwd: 'Forgot password?',
  Login: 'Login',
  DontHaveAccount: 'Don\'t have an account?',
  Signup: 'Sign Up',
  orsignupwithus: 'or sign up with us',

  //Signup
  Name: 'Name',
  Email: 'Email',
  Mobile: 'Mobile No.',
  DOB: 'Date of Birth',
  Gender: 'Gender',
  Signup: 'Sign Up',
  Backto: 'Back to',

  //OTP Screen
  otp: 'OTP',
  verification: 'verification',
  enterotp: 'Enter OTP',
  verify: 'verify',
  resend: 'Resend OTP',

  //Add Video
  Addpost: 'Add to Post',
  post:"Post",

  RiderId:'',
  Token:'',
  BookingId:'',
}

export default FreeText